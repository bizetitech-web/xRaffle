import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import pool, { testConnection } from './config/database.js';

// Get directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load environment variables from server folder
dotenv.config({ path: join(__dirname, '.env') });

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Test database connection on startup
testConnection();

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date(),
    env: process.env.NODE_ENV || 'development'
  });
});

// Database status with more details
app.get('/api/db-status', async (req, res) => {
  try {
    const connection = await pool.getConnection();
    
    // Test query to check if organizations table exists
    const [tables] = await connection.query(
      "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ?",
      [process.env.DB_NAME]
    );
    
    const [orgCount] = await connection.query(
      'SELECT COUNT(*) as count FROM organizations'
    );
    
    connection.release();
    
    res.json({ 
      status: 'connected',
      database: process.env.DB_NAME,
      tables: tables.map(t => t.TABLE_NAME),
      organizationsCount: orgCount[0].count,
      timestamp: new Date()
    });
  } catch (error) {
    console.error('Database status error:', error);
    res.status(500).json({ 
      status: 'disconnected', 
      error: error.message,
      code: error.code
    });
  }
});

// Get test messages (using organizations table)
app.get('/api/test-messages', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, name, created_at FROM organizations ORDER BY created_at DESC LIMIT 10'
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ 
      error: error.message,
      sqlMessage: error.sqlMessage 
    });
  }
});

// Add test message
app.post('/api/test-messages', async (req, res) => {
  const { message } = req.body;
  try {
    // Insert into organizations table
    const [result] = await pool.query(
      'INSERT INTO organizations (name, email, status, created_at) VALUES (?, ?, ?, NOW())',
      [message, `test-${Date.now()}@example.com`, 'active']
    );
    
    // Fetch the inserted record
    const [newRecord] = await pool.query(
      'SELECT id, name, created_at FROM organizations WHERE id = ?',
      [result.insertId]
    );
    
    res.json({ 
      id: newRecord[0].id, 
      message: newRecord[0].name,
      created_at: newRecord[0].created_at 
    });
  } catch (error) {
    console.error('Error inserting message:', error);
    res.status(500).json({ 
      error: error.message,
      sqlMessage: error.sqlMessage 
    });
  }
});

// Diagnostic endpoint
app.get('/api/db-diagnostic', async (req, res) => {
  const results = {
    environment: {
      DB_HOST: process.env.DB_HOST,
      DB_USER: process.env.DB_USER,
      DB_NAME: process.env.DB_NAME,
      PORT: process.env.PORT
    }
  };
  
  try {
    const connection = await pool.getConnection();
    results.connection = 'OK';
    
    // List all tables
    const [tables] = await connection.query('SHOW TABLES');
    results.tables = tables.map(t => Object.values(t)[0]);
    
    // Check organizations table
    try {
      const [orgColumns] = await connection.query('DESCRIBE organizations');
      results.organizations = {
        exists: true,
        columns: orgColumns.map(c => c.Field)
      };
      
      // Sample data
      const [sampleData] = await connection.query('SELECT * FROM organizations LIMIT 3');
      results.sampleData = sampleData;
      
    } catch (e) {
      results.organizations = {
        exists: false,
        error: e.message
      };
    }
    
    connection.release();
    res.json(results);
    
  } catch (error) {
    res.status(500).json({
      error: error.message,
      code: error.code,
      results: results
    });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📁 Environment file: ${join(__dirname, '.env')}`);
  console.log(`🔍 Test endpoints:`);
  console.log(`   - Health: http://localhost:${PORT}/api/health`);
  console.log(`   - DB Status: http://localhost:${PORT}/api/db-status`);
  console.log(`   - Diagnostic: http://localhost:${PORT}/api/db-diagnostic`);
});