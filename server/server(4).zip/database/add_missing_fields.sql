USE bizetcode_stock_db;

-- =====================================================
-- 1. ADD MISSING COLUMNS TO users TABLE
-- =====================================================

-- Add needed columns (compatible with MySQL 5.7 that lacks IF NOT EXISTS on columns)
ALTER TABLE users ADD COLUMN first_name VARCHAR(100) NULL AFTER name;
ALTER TABLE users ADD COLUMN last_name VARCHAR(100) NULL AFTER first_name;
ALTER TABLE users ADD COLUMN phone VARCHAR(50) NULL AFTER email;
ALTER TABLE users ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER password_hash;
ALTER TABLE users ADD COLUMN last_login TIMESTAMP NULL AFTER updated_at;

-- Populate first/last names where possible
UPDATE users 
SET 
  first_name = SUBSTRING_INDEX(name, ' ', 1),
  last_name = SUBSTRING_INDEX(name, ' ', -1)
WHERE 
  (first_name IS NULL OR last_name IS NULL) 
  AND name IS NOT NULL 
  AND name LIKE '% %';

-- For single-word names
UPDATE users 
SET 
  first_name = name,
  last_name = ''
WHERE 
  (first_name IS NULL OR last_name IS NULL) 
  AND name IS NOT NULL 
  AND name NOT LIKE '% %';

-- =====================================================
-- 2. ADD MISSING COLUMNS TO organizations TABLE
-- =====================================================

-- Organizations table already has the needed columns in this schema; no alters required.

-- Generate codes for organizations that don't have them
UPDATE organizations 
SET code = CONCAT(LOWER(REPLACE(name, ' ', '-')), '-', SUBSTRING(MD5(RAND()), 1, 6))
WHERE code IS NULL;

-- =====================================================
-- 3. CREATE audit_logs TABLE IF NOT EXISTS (matches current schema)
-- =====================================================

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT NOT NULL AUTO_INCREMENT,
  user_id CHAR(36) NULL,
  action VARCHAR(150) DEFAULT NULL,
  table_name VARCHAR(100) DEFAULT NULL,
  record_id CHAR(36) DEFAULT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user_id (user_id),
  KEY idx_table_name (table_name),
  KEY idx_created_at (created_at),
  CONSTRAINT audit_logs_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 4. ENSURE user_roles TABLE HAS PROPER STRUCTURE
-- =====================================================

CREATE TABLE IF NOT EXISTS user_roles (
  user_id VARCHAR(36) NOT NULL,
  role_id VARCHAR(36) NOT NULL,
  assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  assigned_by VARCHAR(36) NULL,
  PRIMARY KEY (user_id, role_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 5. ENSURE role_permissions TABLE HAS PROPER STRUCTURE
-- =====================================================

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id VARCHAR(36) NOT NULL,
  permission_id VARCHAR(36) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (role_id, permission_id),
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 6. ADD SAMPLE DATA FOR TESTING
-- =====================================================

-- Insert sample audit log entries if none exist
INSERT INTO audit_logs (user_id, action, table_name, record_id, created_at)
SELECT 
  u.id,
  'LOGIN',
  'users',
  u.id,
  DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 30) DAY)
FROM users u
CROSS JOIN (SELECT 1 UNION SELECT 2 UNION SELECT 3) AS nums
WHERE NOT EXISTS (SELECT 1 FROM audit_logs LIMIT 1)
LIMIT 20;

-- Insert more varied audit logs
INSERT INTO audit_logs (user_id, action, table_name, record_id, created_at)
SELECT 
  u.id,
  CASE FLOOR(RAND() * 5)
    WHEN 0 THEN 'CREATE'
    WHEN 1 THEN 'UPDATE'
    WHEN 2 THEN 'DELETE'
    WHEN 3 THEN 'VIEW'
    ELSE 'EXPORT'
  END,
  CASE FLOOR(RAND() * 4)
    WHEN 0 THEN 'products'
    WHEN 1 THEN 'users'
    WHEN 2 THEN 'sales'
    ELSE 'customers'
  END,
  UUID(),
  DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 60) DAY)
FROM users u
CROSS JOIN (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) AS nums
WHERE (SELECT COUNT(*) FROM audit_logs) < 50
LIMIT 50;

-- =====================================================
-- 7. VERIFY THE STRUCTURE
-- =====================================================

-- Check users table structure
SELECT 'users table columns:' as info;
DESCRIBE users;

-- Check organizations table structure
SELECT 'organizations table columns:' as info;
DESCRIBE organizations;

-- Check audit_logs table
SELECT 'audit_logs table exists:' as info;
SHOW TABLES LIKE 'audit_logs';

-- Count records
SELECT 'Total users:' as info, COUNT(*) as count FROM users;
SELECT 'Total organizations:' as info, COUNT(*) as count FROM organizations;
SELECT 'Total audit logs:' as info, COUNT(*) as count FROM audit_logs;

-- Show sample data
SELECT 'Sample users data:' as info;
SELECT id, email, name, first_name, last_name, is_active FROM users LIMIT 5;

SELECT 'Sample organizations data:' as info;
SELECT id, name, code, is_active FROM organizations LIMIT 5;

SELECT 'Sample audit logs:' as info;
SELECT id, user_id, action, table_name, record_id, created_at FROM audit_logs ORDER BY created_at DESC LIMIT 5;