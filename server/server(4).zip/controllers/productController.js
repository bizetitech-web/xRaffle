import pool from '../config/database.js';
import { v4 as uuidv4 } from 'uuid';

// ==================== PRODUCTS ====================

/**
 * Get all products with pagination, filtering, and sorting
 */
export const getProducts = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const {
      page = 1,
      limit = 20,
      search = '',
      categoryId,
      brandId,
      lowStock,
      sortBy = 'name',
      sortOrder = 'ASC'
    } = req.query;

    const offset = (page - 1) * limit;

    // Build query
    let query = `
      SELECT 
        p.*,
        c.name as category_name,
        c.id as category_id,
        b.name as brand_name,
        b.id as brand_id,
        u.name as unit_name,
        u.id as unit_id
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id AND c.organization_id = ?
      LEFT JOIN brands b ON p.brand_id = b.id AND b.organization_id = ?
      LEFT JOIN units u ON p.unit_id = u.id
      WHERE p.organization_id = ?
    `;
    
    const queryParams = [organizationId, organizationId, organizationId];

    // Add search filter
    if (search) {
      query += ` AND (p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)`;
      const searchTerm = `%${search}%`;
      queryParams.push(searchTerm, searchTerm, searchTerm);
    }

    // Add category filter
    if (categoryId) {
      query += ` AND p.category_id = ?`;
      queryParams.push(categoryId);
    }

    // Add brand filter
    if (brandId) {
      query += ` AND p.brand_id = ?`;
      queryParams.push(brandId);
    }

    // Add low stock filter
    if (lowStock === 'true') {
      query += ` AND p.current_stock <= p.min_stock_level`;
    }

    // Get total count for pagination
    const countQuery = `SELECT COUNT(*) as total FROM (${query}) as countTable`;
    const [countResult] = await pool.query(countQuery, queryParams);
    const total = countResult[0].total;

    // Add sorting and pagination
    const validSortColumns = ['name', 'sku', 'selling_price', 'current_stock', 'created_at'];
    const sortColumn = validSortColumns.includes(sortBy) ? sortBy : 'name';
    const order = sortOrder.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';
    
    query += ` ORDER BY p.${sortColumn} ${order} LIMIT ? OFFSET ?`;
    queryParams.push(parseInt(limit), parseInt(offset));

    // Execute main query
    const [rows] = await pool.query(query, queryParams);

    // Get additional stats for each product
    for (let product of rows) {
      // Get stock movements count
      const [movements] = await pool.query(
        `SELECT COUNT(*) as count FROM inventory_movements WHERE product_id = ?`,
        [product.id]
      );
      product.movements_count = movements[0].count;

      // Get variants count
      const [variants] = await pool.query(
        `SELECT COUNT(*) as count FROM product_variants WHERE product_id = ?`,
        [product.id]
      );
      product.variants_count = variants[0].count;
    }

    res.json({
      products: rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get products error:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
};

/**
 * Get single product by ID
 */
export const getProductById = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const { id } = req.params;

    const [rows] = await pool.query(
      `SELECT 
        p.*,
        c.name as category_name,
        b.name as brand_name,
        u.name as unit_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN brands b ON p.brand_id = b.id
       LEFT JOIN units u ON p.unit_id = u.id
       WHERE p.id = ? AND p.organization_id = ?`,
      [id, organizationId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const product = rows[0];

    // Get price history
    const [priceHistory] = await pool.query(
      `SELECT * FROM product_prices 
       WHERE product_id = ? 
       ORDER BY created_at DESC 
       LIMIT 10`,
      [id]
    );

    // Get variants
    const [variants] = await pool.query(
      `SELECT * FROM product_variants 
       WHERE product_id = ? 
       ORDER BY name`,
      [id]
    );

    // Get tags
    const [tags] = await pool.query(
      `SELECT t.* FROM product_tags t
       JOIN product_tag_map tm ON t.id = tm.tag_id
       WHERE tm.product_id = ?`,
      [id]
    );

    // Get recent inventory movements
    const [movements] = await pool.query(
      `SELECT im.*, 
              c.container_number,
              u.name as user_name
       FROM inventory_movements im
       LEFT JOIN containers c ON im.container_id = c.id
       LEFT JOIN users u ON im.created_by = u.id
       WHERE im.product_id = ?
       ORDER BY im.created_at DESC
       LIMIT 20`,
      [id]
    );

    product.price_history = priceHistory;
    product.variants = variants;
    product.tags = tags;
    product.recent_movements = movements;

    res.json(product);
  } catch (error) {
    console.error('Get product error:', error);
    res.status(500).json({ error: 'Failed to fetch product' });
  }
};

/**
 * Create new product
 */
export const createProduct = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const productId = uuidv4();
    const {
      name,
      sku,
      barcode,
      description,
      cost_price,
      selling_price,
      min_stock_level = 0,
      max_stock_level = 0,
      category_id,
      brand_id,
      unit_id,
      is_active = true,
      variants = [],
      tags = []
    } = req.body;

    // Validate required fields
    if (!name) {
      return res.status(400).json({ error: 'Product name is required' });
    }

    // Check if SKU already exists (if provided)
    if (sku) {
      const [existing] = await connection.query(
        'SELECT id FROM products WHERE sku = ? AND organization_id = ?',
        [sku, organizationId]
      );
      if (existing.length > 0) {
        await connection.rollback();
        return res.status(400).json({ error: 'SKU already exists' });
      }
    }

    // Insert product
    await connection.query(
      `INSERT INTO products (
        id, organization_id, name, sku, barcode, description,
        cost_price, selling_price, min_stock_level, max_stock_level,
        current_stock, category_id, brand_id, unit_id, is_active,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, NOW(), NOW())`,
      [
        productId,
        organizationId,
        name,
        sku || null,
        barcode || null,
        description || null,
        cost_price || 0,
        selling_price || 0,
        min_stock_level,
        max_stock_level,
        category_id || null,
        brand_id || null,
        unit_id || null,
        is_active ? 1 : 0
      ]
    );

    // Add variants if provided
    for (const variant of variants) {
      const variantId = uuidv4();
      await connection.query(
        `INSERT INTO product_variants (
          id, product_id, name, sku, price, cost, quantity, is_active
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          variantId,
          productId,
          variant.name,
          variant.sku || null,
          variant.price || selling_price,
          variant.cost || cost_price,
          variant.quantity || 0,
          1
        ]
      );
    }

    // Add tags if provided
    for (const tagName of tags) {
      // Find or create tag
      let [tagRows] = await connection.query(
        'SELECT id FROM product_tags WHERE name = ? AND organization_id = ?',
        [tagName, organizationId]
      );

      let tagId;
      if (tagRows.length === 0) {
        tagId = uuidv4();
        await connection.query(
          'INSERT INTO product_tags (id, organization_id, name) VALUES (?, ?, ?)',
          [tagId, organizationId, tagName]
        );
      } else {
        tagId = tagRows[0].id;
      }

      // Link tag to product
      await connection.query(
        'INSERT INTO product_tag_map (product_id, tag_id) VALUES (?, ?)',
        [productId, tagId]
      );
    }

    // Log in audit trail
    await connection.query(
      `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'CREATE',
        'product',
        productId,
        JSON.stringify({ name, sku })
      ]
    );

    await connection.commit();

    res.status(201).json({
      message: 'Product created successfully',
      productId
    });
  } catch (error) {
    await connection.rollback();
    console.error('Create product error:', error);
    res.status(500).json({ error: 'Failed to create product' });
  } finally {
    connection.release();
  }
};

/**
 * Update product
 */
export const updateProduct = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const { id } = req.params;
    const {
      name,
      sku,
      barcode,
      description,
      cost_price,
      selling_price,
      min_stock_level,
      max_stock_level,
      category_id,
      brand_id,
      unit_id,
      is_active
    } = req.body;

    // Check if product exists
    const [existing] = await connection.query(
      'SELECT * FROM products WHERE id = ? AND organization_id = ?',
      [id, organizationId]
    );

    if (existing.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: 'Product not found' });
    }

    const product = existing[0];

    // Check if SKU already exists (if changed)
    if (sku && sku !== product.sku) {
      const [skuCheck] = await connection.query(
        'SELECT id FROM products WHERE sku = ? AND organization_id = ? AND id != ?',
        [sku, organizationId, id]
      );
      if (skuCheck.length > 0) {
        await connection.rollback();
        return res.status(400).json({ error: 'SKU already exists' });
      }
    }

    // Track price changes for history
    if (cost_price !== product.cost_price || selling_price !== product.selling_price) {
      await connection.query(
        `INSERT INTO product_prices (
          id, product_id, cost_price, selling_price, changed_at, changed_by
        ) VALUES (?, ?, ?, ?, NOW(), ?)`,
        [uuidv4(), id, product.cost_price, product.selling_price, req.user.sub]
      );
    }

    // Update product
    await connection.query(
      `UPDATE products SET
        name = ?, sku = ?, barcode = ?, description = ?,
        cost_price = ?, selling_price = ?, min_stock_level = ?,
        max_stock_level = ?, category_id = ?, brand_id = ?,
        unit_id = ?, is_active = ?, updated_at = NOW()
       WHERE id = ? AND organization_id = ?`,
      [
        name,
        sku || null,
        barcode || null,
        description || null,
        cost_price,
        selling_price,
        min_stock_level,
        max_stock_level,
        category_id || null,
        brand_id || null,
        unit_id || null,
        is_active ? 1 : 0,
        id,
        organizationId
      ]
    );

    // Log in audit trail
    await connection.query(
      `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'UPDATE',
        'product',
        id,
        JSON.stringify({ changes: req.body })
      ]
    );

    await connection.commit();

    res.json({ message: 'Product updated successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Update product error:', error);
    res.status(500).json({ error: 'Failed to update product' });
  } finally {
    connection.release();
  }
};

/**
 * Delete product (soft delete)
 */
export const deleteProduct = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const { id } = req.params;

    // Check if product exists
    const [product] = await connection.query(
      'SELECT * FROM products WHERE id = ? AND organization_id = ?',
      [id, organizationId]
    );

    if (product.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: 'Product not found' });
    }

    // Check if product has any sales or inventory movements
    const [sales] = await connection.query(
      'SELECT COUNT(*) as count FROM sale_items WHERE product_id = ?',
      [id]
    );

    const [movements] = await connection.query(
      'SELECT COUNT(*) as count FROM inventory_movements WHERE product_id = ?',
      [id]
    );

    if (sales[0].count > 0 || movements[0].count > 0) {
      // Soft delete by deactivating
      await connection.query(
        'UPDATE products SET is_active = 0, updated_at = NOW() WHERE id = ?',
        [id]
      );
      
      await connection.query(
        `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          organizationId,
          'DEACTIVATE',
          'product',
          id,
          JSON.stringify({ reason: 'Has related records' })
        ]
      );
      
      await connection.commit();
      return res.json({ message: 'Product deactivated successfully' });
    } else {
      // Hard delete if no related records
      await connection.query('DELETE FROM product_tag_map WHERE product_id = ?', [id]);
      await connection.query('DELETE FROM product_variants WHERE product_id = ?', [id]);
      await connection.query('DELETE FROM products WHERE id = ?', [id]);
      
      await connection.query(
        `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          organizationId,
          'DELETE',
          'product',
          id,
          JSON.stringify({ permanent: true })
        ]
      );
      
      await connection.commit();
      return res.json({ message: 'Product deleted permanently' });
    }
  } catch (error) {
    await connection.rollback();
    console.error('Delete product error:', error);
    res.status(500).json({ error: 'Failed to delete product' });
  } finally {
    connection.release();
  }
};

/**
 * Search products (for dropdowns/autocomplete)
 */
export const searchProducts = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const { q = '', limit = 10 } = req.query;

    const [rows] = await pool.query(
      `SELECT id, name, sku, selling_price, current_stock
       FROM products
       WHERE organization_id = ? 
         AND (name LIKE ? OR sku LIKE ?)
         AND is_active = 1
       LIMIT ?`,
      [organizationId, `%${q}%`, `%${q}%`, parseInt(limit)]
    );

    res.json(rows);
  } catch (error) {
    console.error('Search products error:', error);
    res.status(500).json({ error: 'Failed to search products' });
  }
};

/**
 * Get low stock products
 */
export const getLowStockProducts = async (req, res) => {
  try {
    const organizationId = req.organizationId;

    const [rows] = await pool.query(
      `SELECT 
        p.*,
        c.name as category_name,
        b.name as brand_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN brands b ON p.brand_id = b.id
       WHERE p.organization_id = ? 
         AND p.current_stock <= p.min_stock_level
         AND p.is_active = 1
       ORDER BY (p.current_stock / p.min_stock_level) ASC`,
      [organizationId]
    );

    res.json(rows);
  } catch (error) {
    console.error('Low stock error:', error);
    res.status(500).json({ error: 'Failed to fetch low stock products' });
  }
};

// ==================== CATEGORIES ====================

/**
 * Get all categories
 */
export const getCategories = async (req, res) => {
  try {
    const organizationId = req.organizationId;

    const [rows] = await pool.query(
      `SELECT c.*, COUNT(p.id) as product_count
       FROM categories c
       LEFT JOIN products p ON c.id = p.category_id AND p.organization_id = ? AND p.is_active = 1
       WHERE c.organization_id = ?
       GROUP BY c.id
       ORDER BY c.name`,
      [organizationId, organizationId]
    );

    res.json(rows);
  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
};

/**
 * Create category
 */
export const createCategory = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const { name, description } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Category name is required' });
    }

    // Check if category name already exists
    const [existing] = await pool.query(
      'SELECT id FROM categories WHERE name = ? AND organization_id = ?',
      [name, organizationId]
    );

    if (existing.length > 0) {
      return res.status(400).json({ error: 'Category name already exists' });
    }

    const categoryId = uuidv4();

    await pool.query(
      `INSERT INTO categories (id, organization_id, name, description, created_at, updated_at)
       VALUES (?, ?, ?, ?, NOW(), NOW())`,
      [categoryId, organizationId, name, description || null]
    );

    // Log action
    await pool.query(
      `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'CREATE',
        'category',
        categoryId,
        JSON.stringify({ name })
      ]
    );

    res.status(201).json({
      message: 'Category created successfully',
      categoryId
    });
  } catch (error) {
    console.error('Create category error:', error);
    res.status(500).json({ error: 'Failed to create category' });
  }
};

/**
 * Update category
 */
export const updateCategory = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const { id } = req.params;
    const { name, description } = req.body;

    // Check if category exists
    const [existing] = await pool.query(
      'SELECT * FROM categories WHERE id = ? AND organization_id = ?',
      [id, organizationId]
    );

    if (existing.length === 0) {
      return res.status(404).json({ error: 'Category not found' });
    }

    // Check if new name conflicts with another category
    if (name && name !== existing[0].name) {
      const [nameCheck] = await pool.query(
        'SELECT id FROM categories WHERE name = ? AND organization_id = ? AND id != ?',
        [name, organizationId, id]
      );
      if (nameCheck.length > 0) {
        return res.status(400).json({ error: 'Category name already exists' });
      }
    }

    await pool.query(
      `UPDATE categories SET name = ?, description = ?, updated_at = NOW()
       WHERE id = ? AND organization_id = ?`,
      [name, description || null, id, organizationId]
    );

    // Log action
    await pool.query(
      `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'UPDATE',
        'category',
        id,
        JSON.stringify({ name, description })
      ]
    );

    res.json({ message: 'Category updated successfully' });
  } catch (error) {
    console.error('Update category error:', error);
    res.status(500).json({ error: 'Failed to update category' });
  }
};

/**
 * Delete category
 */
export const deleteCategory = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const { id } = req.params;

    // Check if category has products
    const [productCount] = await connection.query(
      'SELECT COUNT(*) as count FROM products WHERE category_id = ?',
      [id]
    );

    if (productCount[0].count > 0) {
      await connection.rollback();
      return res.status(400).json({ 
        error: 'Cannot delete category with existing products. Reassign products first.' 
      });
    }

    await connection.query(
      'DELETE FROM categories WHERE id = ? AND organization_id = ?',
      [id, organizationId]
    );

    // Log action
    await connection.query(
      `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'DELETE',
        'category',
        id,
        JSON.stringify({ deleted: true })
      ]
    );

    await connection.commit();

    res.json({ message: 'Category deleted successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Delete category error:', error);
    res.status(500).json({ error: 'Failed to delete category' });
  } finally {
    connection.release();
  }
};

// ==================== BRANDS ====================

/**
 * Get all brands
 */
export const getBrands = async (req, res) => {
  try {
    const organizationId = req.organizationId;

    const [rows] = await pool.query(
      `SELECT b.*, COUNT(p.id) as product_count
       FROM brands b
       LEFT JOIN products p ON b.id = p.brand_id AND p.organization_id = ? AND p.is_active = 1
       WHERE b.organization_id = ?
       GROUP BY b.id
       ORDER BY b.name`,
      [organizationId, organizationId]
    );

    res.json(rows);
  } catch (error) {
    console.error('Get brands error:', error);
    res.status(500).json({ error: 'Failed to fetch brands' });
  }
};

/**
 * Create brand
 */
export const createBrand = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const { name, description } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Brand name is required' });
    }

    // Check if brand name already exists
    const [existing] = await pool.query(
      'SELECT id FROM brands WHERE name = ? AND organization_id = ?',
      [name, organizationId]
    );

    if (existing.length > 0) {
      return res.status(400).json({ error: 'Brand name already exists' });
    }

    const brandId = uuidv4();

    await pool.query(
      `INSERT INTO brands (id, organization_id, name, description, created_at, updated_at)
       VALUES (?, ?, ?, ?, NOW(), NOW())`,
      [brandId, organizationId, name, description || null]
    );

    // Log action
    await pool.query(
      `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'CREATE',
        'brand',
        brandId,
        JSON.stringify({ name })
      ]
    );

    res.status(201).json({
      message: 'Brand created successfully',
      brandId
    });
  } catch (error) {
    console.error('Create brand error:', error);
    res.status(500).json({ error: 'Failed to create brand' });
  }
};

/**
 * Update brand
 */
export const updateBrand = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const { id } = req.params;
    const { name, description } = req.body;

    // Check if brand exists
    const [existing] = await pool.query(
      'SELECT * FROM brands WHERE id = ? AND organization_id = ?',
      [id, organizationId]
    );

    if (existing.length === 0) {
      return res.status(404).json({ error: 'Brand not found' });
    }

    // Check if new name conflicts with another brand
    if (name && name !== existing[0].name) {
      const [nameCheck] = await pool.query(
        'SELECT id FROM brands WHERE name = ? AND organization_id = ? AND id != ?',
        [name, organizationId, id]
      );
      if (nameCheck.length > 0) {
        return res.status(400).json({ error: 'Brand name already exists' });
      }
    }

    await pool.query(
      `UPDATE brands SET name = ?, description = ?, updated_at = NOW()
       WHERE id = ? AND organization_id = ?`,
      [name, description || null, id, organizationId]
    );

    // Log action
    await pool.query(
      `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'UPDATE',
        'brand',
        id,
        JSON.stringify({ name, description })
      ]
    );

    res.json({ message: 'Brand updated successfully' });
  } catch (error) {
    console.error('Update brand error:', error);
    res.status(500).json({ error: 'Failed to update brand' });
  }
};

/**
 * Delete brand
 */
export const deleteBrand = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const { id } = req.params;

    // Check if brand has products
    const [productCount] = await connection.query(
      'SELECT COUNT(*) as count FROM products WHERE brand_id = ?',
      [id]
    );

    if (productCount[0].count > 0) {
      await connection.rollback();
      return res.status(400).json({ 
        error: 'Cannot delete brand with existing products. Reassign products first.' 
      });
    }

    await connection.query(
      'DELETE FROM brands WHERE id = ? AND organization_id = ?',
      [id, organizationId]
    );

    // Log action
    await connection.query(
      `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'DELETE',
        'brand',
        id,
        JSON.stringify({ deleted: true })
      ]
    );

    await connection.commit();

    res.json({ message: 'Brand deleted successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Delete brand error:', error);
    res.status(500).json({ error: 'Failed to delete brand' });
  } finally {
    connection.release();
  }
};

// ==================== UNITS ====================

/**
 * Get all units
 */
export const getUnits = async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM units ORDER BY name'
    );
    res.json(rows);
  } catch (error) {
    console.error('Get units error:', error);
    res.status(500).json({ error: 'Failed to fetch units' });
  }
};