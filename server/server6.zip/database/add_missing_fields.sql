-- =====================================================
-- 8. CREATE product_tags TABLE IF NOT EXISTS
-- =====================================================

CREATE TABLE IF NOT EXISTS product_tags (
  id CHAR(36) PRIMARY KEY,
  organization_id CHAR(36) NOT NULL,
  name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_tag_per_org (organization_id, name),
  FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE
);

-- Idempotent migration: ensure organization_id, unique index and FK exist
-- Adds organization_id column (nullable), unique index, and FK if missing.
-- Safe to run multiple times on MySQL 5.7+.

SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_tags' AND COLUMN_NAME = 'organization_id'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "organization_id already exists"',
  'ALTER TABLE product_tags ADD COLUMN organization_id CHAR(36) NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- OPTIONAL: assign a default organization to existing rows (uncomment and set UUID)
-- SET @default_org = 'd21b3c72-1adc-11f1-a8a6-017031a4a447';
-- UPDATE product_tags SET organization_id = @default_org WHERE organization_id IS NULL;

SET @idx_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_tags' AND INDEX_NAME = 'unique_tag_per_org'
);
SET @sql = IF(@idx_exists > 0,
  'SELECT "unique_tag_per_org exists"',
  'ALTER TABLE product_tags ADD UNIQUE KEY unique_tag_per_org (organization_id, name)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @fk_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'product_tags'
    AND COLUMN_NAME = 'organization_id'
    AND REFERENCED_TABLE_NAME = 'organizations'
);
SET @sql = IF(@fk_exists > 0,
  'SELECT "FK exists"',
  'ALTER TABLE product_tags ADD CONSTRAINT fk_product_tags_organization FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- OPTIONAL: make organization_id NOT NULL after backfilling existing rows
-- Check for NULLs first:
-- SELECT COUNT(*) AS null_count FROM product_tags WHERE organization_id IS NULL;
-- If 0 then run:
-- ALTER TABLE product_tags MODIFY COLUMN organization_id CHAR(36) NOT NULL;

USE bizetcode_stock_db;

-- =====================================================
-- 1. ADD MISSING COLUMNS TO users TABLE
-- =====================================================

-- Add needed columns (compatible with MySQL 5.7 that lacks IF NOT EXISTS on columns)
ALTER TABLE users ADD COLUMN first_name VARCHAR(100) NULL AFTER name;
ALTER TABLE users ADD COLUMN last_name VARCHAR(100) NULL AFTER first_name;
ALTER TABLE users ADD COLUMN phone VARCHAR(50) NULL AFTER email;
ALTER TABLE users ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER password_hash;
ALTER TABLE users ADD COLUMN last_login TIMESTAMP NULL AFTER updated_at;

-- Populate first/last names where possible
UPDATE users 
SET 
  first_name = SUBSTRING_INDEX(name, ' ', 1),
  last_name = SUBSTRING_INDEX(name, ' ', -1)
WHERE 
  (first_name IS NULL OR last_name IS NULL) 
  AND name IS NOT NULL 
  AND name LIKE '% %';

-- For single-word names
UPDATE users 
SET 
  first_name = name,
  last_name = ''
WHERE 
  (first_name IS NULL OR last_name IS NULL) 
  AND name IS NOT NULL 
  AND name NOT LIKE '% %';

-- =====================================================
-- 2. ADD MISSING COLUMNS TO organizations TABLE
-- =====================================================

-- Organizations table already has the needed columns in this schema; no alters required.

-- Generate codes for organizations that don't have them
UPDATE organizations 
SET code = CONCAT(LOWER(REPLACE(name, ' ', '-')), '-', SUBSTRING(MD5(RAND()), 1, 6))
WHERE code IS NULL;

-- =====================================================
-- 3. CREATE audit_logs TABLE IF NOT EXISTS (matches current schema)
-- =====================================================

CREATE TABLE IF NOT EXISTS audit_logs (
  id CHAR(36) NOT NULL,
  user_id CHAR(36) NULL,
  action VARCHAR(150) DEFAULT NULL,
  table_name VARCHAR(100) DEFAULT NULL,
  record_id CHAR(36) DEFAULT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_user_id (user_id),
  KEY idx_table_name (table_name),
  KEY idx_created_at (created_at),
  CONSTRAINT audit_logs_user_fk FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 4. ENSURE user_roles TABLE HAS PROPER STRUCTURE
-- =====================================================

CREATE TABLE IF NOT EXISTS user_roles (
  user_id VARCHAR(36) NOT NULL,
  role_id VARCHAR(36) NOT NULL,
  assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  assigned_by VARCHAR(36) NULL,
  PRIMARY KEY (user_id, role_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 5. ENSURE role_permissions TABLE HAS PROPER STRUCTURE
-- =====================================================

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id VARCHAR(36) NOT NULL,
  permission_id VARCHAR(36) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (role_id, permission_id),
  FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 6. ADD SAMPLE DATA FOR TESTING
-- =====================================================

-- Insert sample audit log entries if none exist
INSERT INTO audit_logs (user_id, action, table_name, record_id, created_at)
SELECT 
  u.id,
  'LOGIN',
  'users',
  u.id,
  DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 30) DAY)
FROM users u
CROSS JOIN (SELECT 1 UNION SELECT 2 UNION SELECT 3) AS nums
WHERE NOT EXISTS (SELECT 1 FROM audit_logs LIMIT 1)
LIMIT 20;

-- Insert more varied audit logs
INSERT INTO audit_logs (user_id, action, table_name, record_id, created_at)
SELECT 
  u.id,
  CASE FLOOR(RAND() * 5)
    WHEN 0 THEN 'CREATE'
    WHEN 1 THEN 'UPDATE'
    WHEN 2 THEN 'DELETE'
    WHEN 3 THEN 'VIEW'
    ELSE 'EXPORT'
  END,
  CASE FLOOR(RAND() * 4)
    WHEN 0 THEN 'products'
    WHEN 1 THEN 'users'
    WHEN 2 THEN 'sales'
    ELSE 'customers'
  END,
  UUID(),
  DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 60) DAY)
FROM users u
CROSS JOIN (SELECT 1 UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) AS nums
WHERE (SELECT COUNT(*) FROM audit_logs) < 50
LIMIT 50;

-- =====================================================
-- 7. VERIFY THE STRUCTURE
-- =====================================================

-- Check users table structure
SELECT 'users table columns:' as info;
DESCRIBE users;

-- Check organizations table structure
SELECT 'organizations table columns:' as info;
DESCRIBE organizations;

-- Check audit_logs table
SELECT 'audit_logs table exists:' as info;
SHOW TABLES LIKE 'audit_logs';

-- Count records
SELECT 'Total users:' as info, COUNT(*) as count FROM users;
SELECT 'Total organizations:' as info, COUNT(*) as count FROM organizations;
SELECT 'Total audit logs:' as info, COUNT(*) as count FROM audit_logs;

-- Show sample data
SELECT 'Sample users data:' as info;
SELECT id, email, name, first_name, last_name, is_active FROM users LIMIT 5;

SELECT 'Sample organizations data:' as info;
SELECT id, name, code, is_active FROM organizations LIMIT 5;

SELECT 'Sample audit logs:' as info;
SELECT id, user_id, action, table_name, record_id, created_at FROM audit_logs ORDER BY created_at DESC LIMIT 5;

-- =====================================================
-- 9. ADD MISSING COLUMNS TO products AND brands
-- =====================================================

-- Add common product fields expected by the application
ALTER TABLE products ADD COLUMN cost_price DECIMAL(10,2) DEFAULT 0.00;
ALTER TABLE products ADD COLUMN selling_price DECIMAL(10,2) DEFAULT 0.00;
ALTER TABLE products ADD COLUMN current_stock INT DEFAULT 0;
ALTER TABLE products ADD COLUMN min_stock_level INT DEFAULT 0;
ALTER TABLE products ADD COLUMN is_active TINYINT(1) DEFAULT 1;
ALTER TABLE products ADD COLUMN created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE products ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Ensure barcode column exists (idempotent)
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products' AND COLUMN_NAME = 'barcode'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "barcode exists"',
  'ALTER TABLE products ADD COLUMN barcode VARCHAR(100) NULL AFTER sku'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Ensure description column exists (idempotent)
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products' AND COLUMN_NAME = 'description'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "description exists"',
  'ALTER TABLE products ADD COLUMN description TEXT NULL AFTER barcode'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Ensure max_stock_level column exists (idempotent)
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'products' AND COLUMN_NAME = 'max_stock_level'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "max_stock_level exists"',
  'ALTER TABLE products ADD COLUMN max_stock_level INT DEFAULT 0 AFTER min_stock_level'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Ensure brands table has timestamps used by insert queries
ALTER TABLE brands ADD COLUMN created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE brands ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- =====================================================
-- 10. ENSURE product_prices TABLE HAS EXPECTED COLUMNS
-- =====================================================

-- Add cost_price column if missing
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_prices' AND COLUMN_NAME = 'cost_price'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "cost_price exists"',
  'ALTER TABLE product_prices ADD COLUMN cost_price DECIMAL(10,2) DEFAULT NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add selling_price column if missing
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_prices' AND COLUMN_NAME = 'selling_price'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "selling_price exists"',
  'ALTER TABLE product_prices ADD COLUMN selling_price DECIMAL(10,2) DEFAULT NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add changed_at timestamp if missing
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_prices' AND COLUMN_NAME = 'changed_at'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "changed_at exists"',
  'ALTER TABLE product_prices ADD COLUMN changed_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add changed_by (user id) if missing
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_prices' AND COLUMN_NAME = 'changed_by'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "changed_by exists"',
  'ALTER TABLE product_prices ADD COLUMN changed_by CHAR(36) NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add an index on product_id if missing
SET @idx_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_prices' AND INDEX_NAME = 'product_id'
);
SET @sql = IF(@idx_exists > 0,
  'SELECT "product_id index exists"',
  'ALTER TABLE product_prices ADD KEY product_id (product_id)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Ensure product_prices.id uses CHAR(36) so UUIDs fit
SELECT DATA_TYPE, COLUMN_TYPE
  INTO @pp_data_type, @pp_column_type
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_prices' AND COLUMN_NAME = 'id';

SET @sql = IF(@pp_data_type IS NULL,
  'SELECT "product_prices table or id column not found"',
  IF(@pp_data_type = 'char' AND @pp_column_type LIKE 'char(36)%',
    'SELECT "product_prices.id already char(36)"',
    'ALTER TABLE product_prices MODIFY COLUMN id CHAR(36) NOT NULL'
  )
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 11. ENSURE product_variants TABLE HAS EXPECTED COLUMNS
-- =====================================================

-- Add `name` column if missing (copy from variant_name when available)
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_variants' AND COLUMN_NAME = 'name'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "name exists"',
  'ALTER TABLE product_variants ADD COLUMN name VARCHAR(150) NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- If `variant_name` exists and `name` is null, copy values
SET @has_variant_name = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_variants' AND COLUMN_NAME = 'variant_name'
);
SET @sql = IF(@has_variant_name > 0,
  'UPDATE product_variants SET name = variant_name WHERE name IS NULL AND variant_name IS NOT NULL',
  'SELECT "skip_product_variants_name_copy"'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add other expected columns if missing
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_variants' AND COLUMN_NAME = 'sku'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "sku exists"',
  'ALTER TABLE product_variants ADD COLUMN sku VARCHAR(100) NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_variants' AND COLUMN_NAME = 'price'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "price exists"',
  'ALTER TABLE product_variants ADD COLUMN price DECIMAL(10,2) DEFAULT NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_variants' AND COLUMN_NAME = 'cost'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "cost exists"',
  'ALTER TABLE product_variants ADD COLUMN cost DECIMAL(10,2) DEFAULT NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_variants' AND COLUMN_NAME = 'quantity'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "quantity exists"',
  'ALTER TABLE product_variants ADD COLUMN quantity INT DEFAULT 0'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'product_variants' AND COLUMN_NAME = 'is_active'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "is_active exists"',
  'ALTER TABLE product_variants ADD COLUMN is_active TINYINT(1) DEFAULT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- =====================================================
-- 10. SAFELY CONVERT audit_logs.id TO CHAR(36) IF NEEDED
-- =====================================================

-- =====================================================
-- 12. ENSURE inventory_movements TABLE HAS EXPECTED COLUMNS
-- =====================================================

-- Add container_id if missing
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'inventory_movements' AND COLUMN_NAME = 'container_id'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "container_id exists"',
  'ALTER TABLE inventory_movements ADD COLUMN container_id CHAR(36) NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add created_by (user id) if missing
SET @col_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'inventory_movements' AND COLUMN_NAME = 'created_by'
);
SET @sql = IF(@col_exists > 0,
  'SELECT "created_by exists"',
  'ALTER TABLE inventory_movements ADD COLUMN created_by CHAR(36) NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;


-- This block checks the current column type and only alters the column
-- when it's missing or not already a CHAR(36). It is safe to run multiple times.
SELECT DATA_TYPE, COLUMN_TYPE
  INTO @data_type, @column_type
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'audit_logs' AND COLUMN_NAME = 'id';

SET @sql = IF(@data_type IS NULL,
  'SELECT "audit_logs table not found or column missing"',
  IF(@data_type = 'char' AND @column_type LIKE 'char(36)%',
    'SELECT "audit_logs.id already char(36)"',
    'ALTER TABLE audit_logs MODIFY COLUMN id CHAR(36) NOT NULL'
  )
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Ensure idx_user_id exists (drop then add is idempotent-safe when index exists)
SET @idx_exists = (
  SELECT COUNT(1) FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'audit_logs' AND INDEX_NAME = 'idx_user_id'
);
SET @sql = IF(@idx_exists > 0, 'SELECT "idx_user_id exists"', 'ALTER TABLE audit_logs ADD KEY idx_user_id (user_id)');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;