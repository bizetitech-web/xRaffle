USE bizetcode_stock_db;

-- Insert sample categories
INSERT INTO categories (id, organization_id, name, description, created_at, updated_at)
SELECT 
  UUID(), 
  o.id,
  'Electronics',
  'Electronic devices and components',
  NOW(),
  NOW()
FROM organizations o
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Electronics');

INSERT INTO categories (id, organization_id, name, description, created_at, updated_at)
SELECT 
  UUID(), 
  o.id,
  'Furniture',
  'Office and warehouse furniture',
  NOW(),
  NOW()
FROM organizations o
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Furniture');

INSERT INTO categories (id, organization_id, name, description, created_at, updated_at)
SELECT 
  UUID(), 
  o.id,
  'Supplies',
  'Office and warehouse supplies',
  NOW(),
  NOW()
FROM organizations o
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE name = 'Supplies');

-- Insert sample brands
INSERT INTO brands (id, organization_id, name, description, created_at, updated_at)
SELECT 
  UUID(), 
  o.id,
  'Generic',
  'Generic brand',
  NOW(),
  NOW()
FROM organizations o
WHERE NOT EXISTS (SELECT 1 FROM brands WHERE name = 'Generic');

-- Insert sample units
INSERT INTO units (id, name, abbreviation, created_at, updated_at)
SELECT UUID(), 'Piece', 'pc', NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM units WHERE name = 'Piece');

INSERT INTO units (id, name, abbreviation, created_at, updated_at)
SELECT UUID(), 'Box', 'bx', NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM units WHERE name = 'Box');

INSERT INTO units (id, name, abbreviation, created_at, updated_at)
SELECT UUID(), 'Kilogram', 'kg', NOW(), NOW()
WHERE NOT EXISTS (SELECT 1 FROM units WHERE name = 'Kilogram');

-- Insert sample products for each organization
INSERT INTO products (
  id, organization_id, name, sku, description,
  cost_price, selling_price, current_stock, min_stock_level,
  category_id, unit_id, is_active, created_at, updated_at
)
SELECT 
  UUID(),
  o.id,
  'Laptop Computer',
  CONCAT('LAP-', SUBSTRING(MD5(RAND()), 1, 6)),
  'High-performance laptop',
  800.00,
  1200.00,
  FLOOR(5 + RAND() * 20),
  5,
  (SELECT id FROM categories WHERE name = 'Electronics' LIMIT 1),
  (SELECT id FROM units WHERE name = 'Piece' LIMIT 1),
  1,
  NOW(),
  NOW()
FROM organizations o;

INSERT INTO products (
  id, organization_id, name, sku, description,
  cost_price, selling_price, current_stock, min_stock_level,
  category_id, unit_id, is_active, created_at, updated_at
)
SELECT 
  UUID(),
  o.id,
  'Office Desk',
  CONCAT('DSK-', SUBSTRING(MD5(RAND()), 1, 6)),
  'Standard office desk',
  150.00,
  250.00,
  FLOOR(2 + RAND() * 10),
  3,
  (SELECT id FROM categories WHERE name = 'Furniture' LIMIT 1),
  (SELECT id FROM units WHERE name = 'Piece' LIMIT 1),
  1,
  NOW(),
  NOW()
FROM organizations o;

INSERT INTO products (
  id, organization_id, name, sku, description,
  cost_price, selling_price, current_stock, min_stock_level,
  category_id, unit_id, is_active, created_at, updated_at
)
SELECT 
  UUID(),
  o.id,
  'Printer Paper',
  CONCAT('PAP-', SUBSTRING(MD5(RAND()), 1, 6)),
  'A4 printer paper, 500 sheets',
  3.50,
  5.99,
  FLOOR(10 + RAND() * 50),
  20,
  (SELECT id FROM categories WHERE name = 'Supplies' LIMIT 1),
  (SELECT id FROM units WHERE name = 'Box' LIMIT 1),
  1,
  NOW(),
  NOW()
FROM organizations o;

-- Create sample customers
INSERT INTO customers (id, organization_id, name, email, phone, created_at, updated_at)
SELECT 
  UUID(),
  o.id,
  'ABC Company',
  'info@abccompany.com',
  '+1234567890',
  NOW(),
  NOW()
FROM organizations o
WHERE NOT EXISTS (SELECT 1 FROM customers WHERE email = 'info@abccompany.com');

INSERT INTO customers (id, organization_id, name, email, phone, created_at, updated_at)
SELECT 
  UUID(),
  o.id,
  'XYZ Corporation',
  'contact@xyzcorp.com',
  '+0987654321',
  NOW(),
  NOW()
FROM organizations o
WHERE NOT EXISTS (SELECT 1 FROM customers WHERE email = 'contact@xyzcorp.com');

-- Create sample sales
INSERT INTO sales (id, organization_id, invoice_number, customer_id, total_amount, status, created_at)
SELECT 
  UUID(),
  o.id,
  CONCAT('INV-', DATE_FORMAT(NOW(), '%Y%m'), '-', FLOOR(1000 + RAND() * 9000)),
  (SELECT id FROM customers WHERE organization_id = o.id LIMIT 1),
  ROUND(100 + RAND() * 900, 2),
  'completed',
  DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 30) DAY)
FROM organizations o
CROSS JOIN (SELECT 1 UNION SELECT 2 UNION SELECT 3) AS nums;

-- Create sample inventory movements
INSERT INTO inventory_movements (
  id, organization_id, product_id, quantity, 
  type, reference_type, reference_id, notes, created_by, created_at
)
SELECT 
  UUID(),
  p.organization_id,
  p.id,
  FLOOR(1 + RAND() * 10),
  CASE FLOOR(RAND() * 2) WHEN 0 THEN 'in' ELSE 'out' END,
  'adjustment',
  NULL,
  'Sample movement',
  (SELECT id FROM users WHERE organization_id = p.organization_id LIMIT 1),
  DATE_SUB(NOW(), INTERVAL FLOOR(RAND() * 60) DAY)
FROM products p
CROSS JOIN (SELECT 1 UNION SELECT 2) AS nums
LIMIT 20;