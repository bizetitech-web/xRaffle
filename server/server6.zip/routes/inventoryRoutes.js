import express from 'express';
import { body, param, query, validationResult } from 'express-validator';
import { authenticate } from '../middleware/auth.js';
import { hasPermission, canAccessOrganization } from '../middleware/rbac.js';
import * as inventoryController from '../controllers/inventoryController.js';

const router = express.Router();

// All inventory routes require authentication and organization access
router.use(authenticate);
router.use(canAccessOrganization);

// ==================== CONTAINER ROUTES ====================

/**
 * @route   GET /api/inventory/containers
 * @desc    Get all containers with pagination
 * @access  Private (VIEW_CONTAINERS permission required)
 */
router.get('/containers',
  hasPermission(['VIEW_CONTAINERS']),
  inventoryController.getContainers
);

/**
 * @route   GET /api/inventory/containers/:id
 * @desc    Get single container by ID
 * @access  Private (VIEW_CONTAINERS permission required)
 */
router.get('/containers/:id',
  param('id').isUUID(),
  hasPermission(['VIEW_CONTAINERS']),
  inventoryController.getContainerById
);

/**
 * @route   POST /api/inventory/containers
 * @desc    Create new container
 * @access  Private (MANAGE_CONTAINERS permission required)
 */
router.post('/containers',
  hasPermission(['MANAGE_CONTAINERS']),
  [
    body('container_number').notEmpty().trim(),
    body('reference_number').optional().trim(),
    body('carrier').optional().trim(),
    body('expected_date').optional().isISO8601(),
    body('arrival_date').optional().isISO8601(),
    body('notes').optional().trim(),
    body('status').optional().isIn(['in_transit', 'arrived', 'delayed', 'cancelled'])
  ],
  inventoryController.createContainer
);

/**
 * @route   PUT /api/inventory/containers/:id
 * @desc    Update container
 * @access  Private (MANAGE_CONTAINERS permission required)
 */
router.put('/containers/:id',
  param('id').isUUID(),
  hasPermission(['MANAGE_CONTAINERS']),
  inventoryController.updateContainer
);

/**
 * @route   DELETE /api/inventory/containers/:id
 * @desc    Delete container
 * @access  Private (MANAGE_CONTAINERS permission required)
 */
router.delete('/containers/:id',
  param('id').isUUID(),
  hasPermission(['MANAGE_CONTAINERS']),
  inventoryController.deleteContainer
);

// ==================== CONTAINER ITEMS ROUTES ====================

/**
 * @route   POST /api/inventory/containers/:containerId/items
 * @desc    Add item to container
 * @access  Private (MANAGE_CONTAINERS permission required)
 */
router.post('/containers/:containerId/items',
  param('containerId').isUUID(),
  hasPermission(['MANAGE_CONTAINERS']),
  [
    body('product_id').isUUID(),
    body('quantity').isInt({ min: 1 }),
    body('unit_price').optional().isFloat({ min: 0 }),
    body('batch_number').optional().trim(),
    body('expiry_date').optional().isISO8601(),
    body('notes').optional().trim()
  ],
  inventoryController.addContainerItem
);

/**
 * @route   PUT /api/inventory/containers/:containerId/items/:itemId
 * @desc    Update container item
 * @access  Private (MANAGE_CONTAINERS permission required)
 */
router.put('/containers/:containerId/items/:itemId',
  param('containerId').isUUID(),
  param('itemId').isUUID(),
  hasPermission(['MANAGE_CONTAINERS']),
  inventoryController.updateContainerItem
);

/**
 * @route   DELETE /api/inventory/containers/:containerId/items/:itemId
 * @desc    Remove item from container
 * @access  Private (MANAGE_CONTAINERS permission required)
 */
router.delete('/containers/:containerId/items/:itemId',
  param('containerId').isUUID(),
  param('itemId').isUUID(),
  hasPermission(['MANAGE_CONTAINERS']),
  inventoryController.removeContainerItem
);

// ==================== STOCK ADJUSTMENT ROUTES ====================

/**
 * @route   GET /api/inventory/stock-adjustments
 * @desc    Get all stock adjustments
 * @access  Private (VIEW_STOCK_ADJUSTMENTS permission required)
 */
router.get('/stock-adjustments',
  hasPermission(['VIEW_STOCK_ADJUSTMENTS']),
  inventoryController.getStockAdjustments
);

/**
 * @route   GET /api/inventory/stock-adjustments/:id
 * @desc    Get stock adjustment by ID
 * @access  Private (VIEW_STOCK_ADJUSTMENTS permission required)
 */
router.get('/stock-adjustments/:id',
  param('id').isUUID(),
  hasPermission(['VIEW_STOCK_ADJUSTMENTS']),
  inventoryController.getStockAdjustmentById
);

/**
 * @route   POST /api/inventory/stock-adjustments
 * @desc    Create new stock adjustment
 * @access  Private (CREATE_STOCK_ADJUSTMENTS permission required)
 */
router.post('/stock-adjustments',
  hasPermission(['CREATE_STOCK_ADJUSTMENTS']),
  [
    body('adjustment_type').isIn(['increase', 'decrease', 'correction']),
    body('reason').notEmpty().trim(),
    body('reference_number').optional().trim(),
    body('notes').optional().trim(),
    body('items').isArray({ min: 1 })
  ],
  inventoryController.createStockAdjustment
);

// ==================== INVENTORY MOVEMENT ROUTES ====================

/**
 * @route   GET /api/inventory/movements
 * @desc    Get inventory movements with filters
 * @access  Private (VIEW_INVENTORY_MOVEMENTS permission required)
 */
router.get('/movements',
  hasPermission(['VIEW_INVENTORY_MOVEMENTS']),
  inventoryController.getInventoryMovements
);

/**
 * @route   GET /api/inventory/movements/summary
 * @desc    Get inventory movement summary
 * @access  Private (VIEW_INVENTORY_MOVEMENTS permission required)
 */
router.get('/movements/summary',
  hasPermission(['VIEW_INVENTORY_MOVEMENTS']),
  inventoryController.getMovementSummary
);

export default router;