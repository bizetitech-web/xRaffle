import express from 'express';
import { authenticate } from '../middleware/auth.js';
import { canAccessOrganization } from '../middleware/rbac.js';
import { getDashboardStats, getInventoryChart } from '../controllers/dashboardController.js';

const router = express.Router();

// All dashboard routes require authentication and organization access
router.use(authenticate);
router.use(canAccessOrganization);

// Get dashboard statistics
router.get('/stats', getDashboardStats);

// Get inventory chart data
router.get('/chart', getInventoryChart);

export default router;