import express from 'express';
import { body, param, query, validationResult } from 'express-validator';
import { authenticate } from '../middleware/auth.js';
import { hasPermission, canAccessOrganization } from '../middleware/rbac.js';
import pool from '../config/database.js';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();

// Apply authentication and organization access to all routes
router.use(authenticate);
router.use(canAccessOrganization);

// ==================== VALIDATION MIDDLEWARE ====================

const validateProduct = [
  body('name').notEmpty().trim().escape(),
  body('sku').optional().trim().escape(),
  body('barcode').optional().trim().escape(),
  body('description').optional().trim().escape(),
  body('cost_price').optional().isFloat({ min: 0 }),
  body('selling_price').optional().isFloat({ min: 0 }),
  body('min_stock_level').optional().isInt({ min: 0 }),
  body('max_stock_level').optional().isInt({ min: 0 }),
  body('category_id').optional().isUUID(),
  body('brand_id').optional().isUUID(),
  body('unit_id').optional().isUUID(),
  body('is_active').optional().isBoolean(),
  body('variants').optional().isArray(),
  body('tags').optional().isArray(),
];

const validateBrand = [
  body('name').notEmpty().trim().escape(),
  body('description').optional().trim().escape(),
];

const validateVariant = [
  body('name').notEmpty().trim().escape(),
  body('sku').optional().trim().escape(),
  body('price').optional().isFloat({ min: 0 }),
  body('cost').optional().isFloat({ min: 0 }),
  body('quantity').optional().isInt({ min: 0 }),
];

// ==================== PRODUCT ROUTES ====================

/**
 * @route   GET /api/products
 * @desc    List products with pagination, filtering, and sorting
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/', 
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
      const organizationId = req.organizationId;
      const {
        page = 1,
        limit = 20,
        search = '',
        categoryId,
        brandId,
        lowStock,
        sortBy = 'name',
        sortOrder = 'ASC'
      } = req.query;

      const offset = (page - 1) * limit;

      // Build query
      let query = `
        SELECT 
          p.*,
          c.name as category_name,
          c.id as category_ref_id,
          b.name as brand_name,
          b.id as brand_ref_id,
          u.name as unit_name,
          u.id as unit_ref_id
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id AND c.organization_id = ?
        LEFT JOIN brands b ON p.brand_id = b.id AND b.organization_id = ?
        LEFT JOIN units u ON p.unit_id = u.id
        WHERE p.organization_id = ?
      `;
      
      const queryParams = [organizationId, organizationId, organizationId];

      // Add search filter
      if (search) {
        query += ` AND (p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)`;
        const searchTerm = `%${search}%`;
        queryParams.push(searchTerm, searchTerm, searchTerm);
      }

      // Add category filter
      if (categoryId) {
        query += ` AND p.category_id = ?`;
        queryParams.push(categoryId);
      }

      // Add brand filter
      if (brandId) {
        query += ` AND p.brand_id = ?`;
        queryParams.push(brandId);
      }

      // Add low stock filter
      if (lowStock === 'true') {
        query += ` AND p.current_stock <= p.min_stock_level`;
      }

      // Get total count for pagination
      const countQuery = `SELECT COUNT(*) as total FROM (${query}) as countTable`;
      const [countResult] = await pool.query(countQuery, queryParams);
      const total = countResult[0].total;

      // Add sorting and pagination
      const validSortColumns = ['name', 'sku', 'selling_price', 'current_stock', 'created_at'];
      const sortColumn = validSortColumns.includes(sortBy) ? sortBy : 'name';
      const order = sortOrder.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';
      
      query += ` ORDER BY p.${sortColumn} ${order} LIMIT ? OFFSET ?`;
      queryParams.push(parseInt(limit), parseInt(offset));

      // Execute main query
      const [rows] = await pool.query(query, queryParams);

      // Get additional stats for each product
      for (let product of rows) {
        // Get stock movements count
        const [movements] = await pool.query(
          `SELECT COUNT(*) as count FROM inventory_movements WHERE product_id = ?`,
          [product.id]
        );
        product.movements_count = movements[0].count;

        // Get variants count
        const [variants] = await pool.query(
          `SELECT COUNT(*) as count FROM product_variants WHERE product_id = ?`,
          [product.id]
        );
        product.variants_count = variants[0].count;

        // Get tags
        const [tags] = await pool.query(
          `SELECT t.name FROM product_tags t
           JOIN product_tag_map tm ON t.id = tm.tag_id
           WHERE tm.product_id = ?`,
          [product.id]
        );
        product.tags = tags.map(t => t.name);
      }

      res.json({
        products: rows,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          pages: Math.ceil(total / limit)
        }
      });
    } catch (error) {
      console.error('List products error:', error);
      res.status(500).json({ error: 'Failed to fetch products' });
    }
  }
);

/**
 * @route   GET /api/products/search
 * @desc    Search products (for dropdowns/autocomplete)
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/search',
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
      const organizationId = req.organizationId;
      const { q = '', limit = 10 } = req.query;

      const [rows] = await pool.query(
        `SELECT id, name, sku, selling_price, current_stock
         FROM products
         WHERE organization_id = ? 
           AND (name LIKE ? OR sku LIKE ?)
           AND is_active = 1
         LIMIT ?`,
        [organizationId, `%${q}%`, `%${q}%`, parseInt(limit)]
      );

      res.json(rows);
    } catch (error) {
      console.error('Search products error:', error);
      res.status(500).json({ error: 'Failed to search products' });
    }
  }
);

/**
 * @route   GET /api/products/low-stock
 * @desc    Get products with low stock
 * @access  Private (VIEW_LOW_STOCK_ALERTS permission required)
 */
router.get('/low-stock',
  hasPermission(['VIEW_LOW_STOCK_ALERTS']),
  async (req, res) => {
    try {
      const organizationId = req.organizationId;

      const [rows] = await pool.query(
        `SELECT 
          p.*,
          c.name as category_name,
          b.name as brand_name
         FROM products p
         LEFT JOIN categories c ON p.category_id = c.id
         LEFT JOIN brands b ON p.brand_id = b.id
         WHERE p.organization_id = ? 
           AND p.current_stock <= p.min_stock_level
           AND p.is_active = 1
         ORDER BY (p.current_stock / p.min_stock_level) ASC`,
        [organizationId]
      );

      res.json(rows);
    } catch (error) {
      console.error('Low stock error:', error);
      res.status(500).json({ error: 'Failed to fetch low stock products' });
    }
  }
);

/**
 * @route   GET /api/products/export
 * @desc    Export products as CSV
 * @access  Private (EXPORT_DATA permission required)
 */
router.get('/export',
  hasPermission(['EXPORT_DATA']),
  async (req, res) => {
    try {
      const organizationId = req.organizationId;
      
      const [rows] = await pool.query(
        `SELECT 
          p.name, p.sku, p.barcode, p.description,
          p.cost_price, p.selling_price, p.current_stock,
          p.min_stock_level, p.max_stock_level,
          c.name as category, 
          b.name as brand,
          u.name as unit,
          GROUP_CONCAT(DISTINCT t.name) as tags
         FROM products p
         LEFT JOIN categories c ON p.category_id = c.id
         LEFT JOIN brands b ON p.brand_id = b.id
         LEFT JOIN units u ON p.unit_id = u.id
         LEFT JOIN product_tag_map tm ON p.id = tm.product_id
         LEFT JOIN product_tags t ON tm.tag_id = t.id
         WHERE p.organization_id = ? AND p.is_active = 1
         GROUP BY p.id`,
        [organizationId]
      );

      // Create CSV header
      const headers = ['Name', 'SKU', 'Barcode', 'Description', 'Cost Price', 'Selling Price', 
                       'Current Stock', 'Min Stock', 'Max Stock', 'Category', 'Brand', 'Unit', 'Tags'];
      
      // Convert to CSV rows
      const csvRows = [
        headers.join(','),
        ...rows.map(row => 
          Object.values(row).map(value => 
            value ? `"${String(value).replace(/"/g, '""')}"` : ''
          ).join(',')
        )
      ];
      
      const csv = csvRows.join('\n');
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=products.csv');
      res.send(csv);
    } catch (error) {
      console.error('Export error:', error);
      res.status(500).json({ error: 'Failed to export products' });
    }
  }
);

/**
 * @route   GET /api/products/:id
 * @desc    Get single product by ID
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/:id',
  param('id').isUUID(),
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const organizationId = req.organizationId;
      const { id } = req.params;

      const [rows] = await pool.query(
        `SELECT 
          p.*,
          c.name as category_name,
          c.id as category_id,
          b.name as brand_name,
          b.id as brand_id,
          u.name as unit_name,
          u.id as unit_id
         FROM products p
         LEFT JOIN categories c ON p.category_id = c.id
         LEFT JOIN brands b ON p.brand_id = b.id
         LEFT JOIN units u ON p.unit_id = u.id
         WHERE p.id = ? AND p.organization_id = ?`,
        [id, organizationId]
      );

      if (rows.length === 0) {
        return res.status(404).json({ error: 'Product not found' });
      }

      const product = rows[0];

      // Get price history
      const [priceHistory] = await pool.query(
        `SELECT * FROM product_prices 
         WHERE product_id = ? 
         ORDER BY changed_at DESC 
         LIMIT 10`,
        [id]
      );

      // Get variants
      const [variants] = await pool.query(
        `SELECT * FROM product_variants 
         WHERE product_id = ? 
         ORDER BY name`,
        [id]
      );

      // Get tags
      const [tags] = await pool.query(
        `SELECT t.* FROM product_tags t
         JOIN product_tag_map tm ON t.id = tm.tag_id
         WHERE tm.product_id = ?`,
        [id]
      );

      // Get recent inventory movements
      const [movements] = await pool.query(
        `SELECT im.*, 
                c.container_number,
                u.name as user_name
         FROM inventory_movements im
         LEFT JOIN containers c ON im.container_id = c.id
         LEFT JOIN users u ON im.created_by = u.id
         WHERE im.product_id = ?
         ORDER BY im.created_at DESC
         LIMIT 20`,
        [id]
      );

      product.price_history = priceHistory;
      product.variants = variants;
      product.tags = tags;
      product.recent_movements = movements;

      res.json(product);
    } catch (error) {
      console.error('Get product error:', error);
      res.status(500).json({ error: 'Failed to fetch product' });
    }
  }
);

/**
 * @route   POST /api/products
 * @desc    Create new product
 * @access  Private (CREATE_PRODUCTS permission required)
 */
router.post('/',
  validateProduct,
  hasPermission(['CREATE_PRODUCTS']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const organizationId = req.organizationId;
      const productId = uuidv4();
      const {
        name,
        sku,
        barcode,
        description,
        cost_price,
        selling_price,
        min_stock_level = 0,
        max_stock_level = 0,
        category_id,
        brand_id,
        unit_id,
        is_active = true,
        variants = [],
        tags = []
      } = req.body;

      // Validate required fields
      if (!name) {
        await connection.rollback();
        return res.status(400).json({ error: 'Product name is required' });
      }

      // Check if SKU already exists in this organization
      if (sku) {
        const [existing] = await connection.query(
          'SELECT id FROM products WHERE sku = ? AND organization_id = ?',
          [sku, organizationId]
        );
        if (existing.length > 0) {
          await connection.rollback();
          return res.status(400).json({ error: 'SKU already exists' });
        }
      }

      // Insert product
      await connection.query(
        `INSERT INTO products (
          id, organization_id, name, sku, barcode, description,
          cost_price, selling_price, min_stock_level, max_stock_level,
          current_stock, category_id, brand_id, unit_id, is_active,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, NOW(), NOW())`,
        [
          productId, 
          organizationId, 
          name, 
          sku || null, 
          barcode || null,
          description || null, 
          cost_price || 0, 
          selling_price || 0,
          min_stock_level, 
          max_stock_level,
          category_id || null, 
          brand_id || null, 
          unit_id || null,
          is_active ? 1 : 0
        ]
      );

      // Add variants if provided
      for (const variant of variants) {
        const variantId = uuidv4();
        await connection.query(
          `INSERT INTO product_variants (
            id, product_id, name, sku, price, cost, quantity, is_active
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            variantId,
            productId,
            variant.name,
            variant.sku || null,
            variant.price || selling_price,
            variant.cost || cost_price,
            variant.quantity || 0,
            1
          ]
        );
      }

      // Add tags if provided
      for (const tagName of tags) {
        // Find or create tag
        let [tagRows] = await connection.query(
          'SELECT id FROM product_tags WHERE name = ? AND organization_id = ?',
          [tagName, organizationId]
        );

        let tagId;
        if (tagRows.length === 0) {
          tagId = uuidv4();
          await connection.query(
            'INSERT INTO product_tags (id, organization_id, name) VALUES (?, ?, ?)',
            [tagId, organizationId, tagName]
          );
        } else {
          tagId = tagRows[0].id;
        }

        // Link tag to product
        await connection.query(
          'INSERT INTO product_tag_map (product_id, tag_id) VALUES (?, ?)',
          [productId, tagId]
        );
      }

      // Log in audit trail
      await connection.query(
        `INSERT INTO audit_logs (
          id, user_id, organization_id, action, entity_type, entity_id, details, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          organizationId,
          'CREATE',
          'product',
          productId,
          JSON.stringify({ name, sku, variants: variants.length, tags: tags.length })
        ]
      );

      await connection.commit();

      res.status(201).json({
        message: 'Product created successfully',
        productId
      });
    } catch (error) {
      await connection.rollback();
      console.error('Create product error:', error);
      res.status(500).json({ error: 'Failed to create product' });
    } finally {
      connection.release();
    }
  }
);

/**
 * @route   PUT /api/products/:id
 * @desc    Update product
 * @access  Private (EDIT_PRODUCTS permission required)
 */
router.put('/:id',
  param('id').isUUID(),
  validateProduct,
  hasPermission(['EDIT_PRODUCTS']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const organizationId = req.organizationId;
      const { id } = req.params;
      const {
        name,
        sku,
        barcode,
        description,
        cost_price,
        selling_price,
        min_stock_level,
        max_stock_level,
        category_id,
        brand_id,
        unit_id,
        is_active
      } = req.body;

      // Check if product exists
      const [existing] = await connection.query(
        'SELECT * FROM products WHERE id = ? AND organization_id = ?',
        [id, organizationId]
      );

      if (existing.length === 0) {
        await connection.rollback();
        return res.status(404).json({ error: 'Product not found' });
      }

      const product = existing[0];

      // Check if SKU already exists (if changed)
      if (sku && sku !== product.sku) {
        const [skuCheck] = await connection.query(
          'SELECT id FROM products WHERE sku = ? AND organization_id = ? AND id != ?',
          [sku, organizationId, id]
        );
        if (skuCheck.length > 0) {
          await connection.rollback();
          return res.status(400).json({ error: 'SKU already exists' });
        }
      }

      // Track price changes for history
      if (cost_price !== product.cost_price || selling_price !== product.selling_price) {
        await connection.query(
          `INSERT INTO product_prices (
            id, product_id, cost_price, selling_price, changed_at, changed_by
          ) VALUES (?, ?, ?, ?, NOW(), ?)`,
          [uuidv4(), id, product.cost_price, product.selling_price, req.user.sub]
        );
      }

      // Update product
      await connection.query(
        `UPDATE products SET
          name = ?, sku = ?, barcode = ?, description = ?,
          cost_price = ?, selling_price = ?, min_stock_level = ?,
          max_stock_level = ?, category_id = ?, brand_id = ?,
          unit_id = ?, is_active = ?, updated_at = NOW()
         WHERE id = ? AND organization_id = ?`,
        [
          name, 
          sku || null, 
          barcode || null, 
          description || null,
          cost_price, 
          selling_price, 
          min_stock_level, 
          max_stock_level,
          category_id || null, 
          brand_id || null, 
          unit_id || null,
          is_active ? 1 : 0, 
          id, 
          organizationId
        ]
      );

      // Log in audit trail
      await connection.query(
        `INSERT INTO audit_logs (
          id, user_id, organization_id, action, entity_type, entity_id, details, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          organizationId,
          'UPDATE',
          'product',
          id,
          JSON.stringify({ changes: req.body })
        ]
      );

      await connection.commit();

      res.json({ message: 'Product updated successfully' });
    } catch (error) {
      await connection.rollback();
      console.error('Update product error:', error);
      res.status(500).json({ error: 'Failed to update product' });
    } finally {
      connection.release();
    }
  }
);

/**
 * @route   DELETE /api/products/:id
 * @desc    Delete product (soft delete)
 * @access  Private (DELETE_PRODUCTS permission required)
 */
router.delete('/:id',
  param('id').isUUID(),
  hasPermission(['DELETE_PRODUCTS']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const organizationId = req.organizationId;
      const { id } = req.params;

      // Check if product exists
      const [product] = await connection.query(
        'SELECT * FROM products WHERE id = ? AND organization_id = ?',
        [id, organizationId]
      );

      if (product.length === 0) {
        await connection.rollback();
        return res.status(404).json({ error: 'Product not found' });
      }

      // Check if product has any sales or inventory movements
      const [sales] = await connection.query(
        'SELECT COUNT(*) as count FROM sale_items WHERE product_id = ?',
        [id]
      );

      const [movements] = await connection.query(
        'SELECT COUNT(*) as count FROM inventory_movements WHERE product_id = ?',
        [id]
      );

      if (sales[0].count > 0 || movements[0].count > 0) {
        // Soft delete by deactivating
        await connection.query(
          'UPDATE products SET is_active = 0, updated_at = NOW() WHERE id = ?',
          [id]
        );
        
        await connection.query(
          `INSERT INTO audit_logs (
            id, user_id, organization_id, action, entity_type, entity_id, details, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
          [
            uuidv4(),
            req.user.sub,
            organizationId,
            'DEACTIVATE',
            'product',
            id,
            JSON.stringify({ reason: 'Has related records' })
          ]
        );
        
        await connection.commit();
        return res.json({ message: 'Product deactivated successfully' });
      } else {
        // Hard delete if no related records
        await connection.query('DELETE FROM product_tag_map WHERE product_id = ?', [id]);
        await connection.query('DELETE FROM product_variants WHERE product_id = ?', [id]);
        await connection.query('DELETE FROM products WHERE id = ?', [id]);
        
        await connection.query(
          `INSERT INTO audit_logs (
            id, user_id, organization_id, action, entity_type, entity_id, details, created_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
          [
            uuidv4(),
            req.user.sub,
            organizationId,
            'DELETE',
            'product',
            id,
            JSON.stringify({ permanent: true })
          ]
        );
        
        await connection.commit();
        return res.json({ message: 'Product deleted permanently' });
      }
    } catch (error) {
      await connection.rollback();
      console.error('Delete product error:', error);
      res.status(500).json({ error: 'Failed to delete product' });
    } finally {
      connection.release();
    }
  }
);

// ==================== BULK OPERATIONS ====================

/**
 * @route   POST /api/products/bulk/delete
 * @desc    Bulk delete products
 * @access  Private (DELETE_PRODUCTS permission required)
 */
router.post('/bulk/delete',
  hasPermission(['DELETE_PRODUCTS']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      
      const { productIds } = req.body;
      const organizationId = req.organizationId;

      if (!productIds || !Array.isArray(productIds) || productIds.length === 0) {
        return res.status(400).json({ error: 'Product IDs array is required' });
      }

      let deactivated = 0;
      for (const id of productIds) {
        // Check if product has related records
        const [sales] = await connection.query(
          'SELECT COUNT(*) as count FROM sale_items WHERE product_id = ?',
          [id]
        );

        const [movements] = await connection.query(
          'SELECT COUNT(*) as count FROM inventory_movements WHERE product_id = ?',
          [id]
        );

        if (sales[0].count > 0 || movements[0].count > 0) {
          // Soft delete
          await connection.query(
            'UPDATE products SET is_active = 0 WHERE id = ? AND organization_id = ?',
            [id, organizationId]
          );
        } else {
          // Hard delete
          await connection.query('DELETE FROM product_tag_map WHERE product_id = ?', [id]);
          await connection.query('DELETE FROM product_variants WHERE product_id = ?', [id]);
          await connection.query('DELETE FROM products WHERE id = ? AND organization_id = ?', [id, organizationId]);
        }
        deactivated++;
      }

      await connection.commit();
      res.json({ message: `${deactivated} products processed` });
    } catch (error) {
      await connection.rollback();
      console.error('Bulk delete error:', error);
      res.status(500).json({ error: 'Bulk delete failed' });
    } finally {
      connection.release();
    }
  }
);

// ==================== VARIANT ROUTES ====================

/**
 * @route   GET /api/products/:productId/variants
 * @desc    Get variants for a product
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/:productId/variants',
  param('productId').isUUID(),
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
      const { productId } = req.params;
      const [rows] = await pool.query(
        'SELECT * FROM product_variants WHERE product_id = ? ORDER BY name',
        [productId]
      );
      res.json(rows);
    } catch (error) {
      console.error('Get variants error:', error);
      res.status(500).json({ error: 'Failed to fetch variants' });
    }
  }
);

/**
 * @route   POST /api/products/:productId/variants
 * @desc    Add variant to product
 * @access  Private (EDIT_PRODUCTS permission required)
 */
router.post('/:productId/variants',
  param('productId').isUUID(),
  validateVariant,
  hasPermission(['EDIT_PRODUCTS']),
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { productId } = req.params;
      const { name, sku, price, cost, quantity } = req.body;
      const variantId = uuidv4();

      await pool.query(
        `INSERT INTO product_variants (id, product_id, name, sku, price, cost, quantity, is_active)
         VALUES (?, ?, ?, ?, ?, ?, ?, 1)`,
        [variantId, productId, name, sku || null, price || null, cost || null, quantity || 0]
      );

      res.status(201).json({ 
        message: 'Variant added successfully',
        variantId 
      });
    } catch (error) {
      console.error('Add variant error:', error);
      res.status(500).json({ error: 'Failed to add variant' });
    }
  }
);

/**
 * @route   PUT /api/variants/:id
 * @desc    Update variant
 * @access  Private (EDIT_PRODUCTS permission required)
 */
router.put('/variants/:id',
  param('id').isUUID(),
  validateVariant,
  hasPermission(['EDIT_PRODUCTS']),
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { id } = req.params;
      const { name, sku, price, cost, quantity, is_active } = req.body;

      await pool.query(
        `UPDATE product_variants SET
          name = ?, sku = ?, price = ?, cost = ?, quantity = ?, is_active = ?
         WHERE id = ?`,
        [name, sku || null, price, cost, quantity, is_active ? 1 : 0, id]
      );

      res.json({ message: 'Variant updated successfully' });
    } catch (error) {
      console.error('Update variant error:', error);
      res.status(500).json({ error: 'Failed to update variant' });
    }
  }
);

/**
 * @route   DELETE /api/variants/:id
 * @desc    Delete variant
 * @access  Private (EDIT_PRODUCTS permission required)
 */
router.delete('/variants/:id',
  param('id').isUUID(),
  hasPermission(['EDIT_PRODUCTS']),
  async (req, res) => {
    try {
      const { id } = req.params;
      await pool.query('DELETE FROM product_variants WHERE id = ?', [id]);
      res.json({ message: 'Variant deleted successfully' });
    } catch (error) {
      console.error('Delete variant error:', error);
      res.status(500).json({ error: 'Failed to delete variant' });
    }
  }
);

// ==================== TAG ROUTES ====================

/**
 * @route   GET /api/products/tags/list
 * @desc    Get all tags
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/tags/list',
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
        const organizationId = req.organizationId;

        // Try scoped query first. If the database schema doesn't have
        // `organization_id` (older schemas), fall back to an unscoped query.
        let rows;
        try {
          const [r] = await pool.query(
            'SELECT * FROM product_tags WHERE organization_id = ? ORDER BY name',
            [organizationId]
          );
          rows = r;
        } catch (err) {
          // ER_BAD_FIELD_ERROR indicates the column doesn't exist in the table
          if (err && err.code === 'ER_BAD_FIELD_ERROR') {
            console.warn('product_tags table missing organization_id, falling back to unscoped tags query');
            const [r] = await pool.query('SELECT * FROM product_tags ORDER BY name');
            rows = r;
          } else {
            throw err;
          }
        }

        res.json(rows);
    } catch (error) {
      console.error('Get tags error:', error);
      res.status(500).json({ error: 'Failed to fetch tags' });
    }
  }
);

/**
 * @route   POST /api/products/:id/tags
 * @desc    Add tags to product
 * @access  Private (EDIT_PRODUCTS permission required)
 */
router.post('/:id/tags',
  param('id').isUUID(),
  hasPermission(['EDIT_PRODUCTS']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
      
      const { id } = req.params;
      const { tags } = req.body; // array of tag names
      const organizationId = req.organizationId;

      if (!Array.isArray(tags)) {
        return res.status(400).json({ error: 'Tags must be an array' });
      }

      const addedTags = [];

      for (const tagName of tags) {
        // Find or create tag
        let [tagRows] = await connection.query(
          'SELECT id FROM product_tags WHERE name = ? AND organization_id = ?',
          [tagName, organizationId]
        );

        let tagId;
        if (tagRows.length === 0) {
          tagId = uuidv4();
          await connection.query(
            'INSERT INTO product_tags (id, organization_id, name) VALUES (?, ?, ?)',
            [tagId, organizationId, tagName]
          );
          addedTags.push({ id: tagId, name: tagName });
        } else {
          tagId = tagRows[0].id;
        }

        // Link tag to product
        await connection.query(
          'INSERT IGNORE INTO product_tag_map (product_id, tag_id) VALUES (?, ?)',
          [id, tagId]
        );
      }

      await connection.commit();
      res.json({ 
        message: 'Tags added successfully',
        tags: addedTags 
      });
    } catch (error) {
      await connection.rollback();
      console.error('Add tags error:', error);
      res.status(500).json({ error: 'Failed to add tags' });
    } finally {
      connection.release();
    }
  }
);

/**
 * @route   DELETE /api/products/:id/tags/:tagId
 * @desc    Remove tag from product
 * @access  Private (EDIT_PRODUCTS permission required)
 */
router.delete('/:id/tags/:tagId',
  param('id').isUUID(),
  param('tagId').isUUID(),
  hasPermission(['EDIT_PRODUCTS']),
  async (req, res) => {
    try {
      const { id, tagId } = req.params;
      
      await pool.query(
        'DELETE FROM product_tag_map WHERE product_id = ? AND tag_id = ?',
        [id, tagId]
      );

      res.json({ message: 'Tag removed successfully' });
    } catch (error) {
      console.error('Remove tag error:', error);
      res.status(500).json({ error: 'Failed to remove tag' });
    }
  }
);

// ==================== CATEGORY ROUTES ====================

// Validation middleware for categories
const validateCategory = [
  body('name').notEmpty().trim().escape(),
  body('description').optional().trim().escape(),
  body('parent_id').optional().isUUID().custom(async (value, { req }) => {
    if (value) {
      // Check if parent category exists and belongs to same organization
      const [parent] = await pool.query(
        'SELECT id FROM categories WHERE id = ? AND organization_id = ?',
        [value, req.organizationId]
      );
      if (parent.length === 0) {
        throw new Error('Parent category not found');
      }
    }
    return true;
  }),
];

/**
 * @route   GET /api/products/categories/list
 * @desc    List all categories with hierarchy support
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/categories/list',
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
      const organizationId = req.organizationId;

      // Get all categories with product counts and hierarchy info
      const [rows] = await pool.query(
        `SELECT 
          c.id,
          c.name,
          c.description,
          c.parent_id,
          c.created_at,
          c.updated_at,
          c.organization_id,
          pc.name as parent_name,
          COUNT(p.id) as product_count,
          (
            SELECT COUNT(*) FROM categories 
            WHERE parent_id = c.id AND organization_id = ?
          ) as child_count
         FROM categories c
         LEFT JOIN categories pc ON c.parent_id = pc.id AND pc.organization_id = ?
         LEFT JOIN products p ON c.id = p.category_id AND p.organization_id = ?
         WHERE c.organization_id = ?
         GROUP BY c.id
         ORDER BY 
           CASE WHEN c.parent_id IS NULL THEN 0 ELSE 1 END,
           c.parent_id,
           c.name`,
        [organizationId, organizationId, organizationId, organizationId]
      );

      // Organize into hierarchical structure
      const categoryMap = {};
      const rootCategories = [];

      rows.forEach(cat => {
        categoryMap[cat.id] = { ...cat, children: [] };
      });

      rows.forEach(cat => {
        if (cat.parent_id && categoryMap[cat.parent_id]) {
          categoryMap[cat.parent_id].children.push(categoryMap[cat.id]);
        } else {
          rootCategories.push(categoryMap[cat.id]);
        }
      });

      res.json({
        flat: rows,
        hierarchical: rootCategories
      });
    } catch (error) {
      console.error('List categories error:', error);
      res.status(500).json({ error: 'Failed to fetch categories' });
    }
  }
);

/**
 * @route   GET /api/products/categories/:id
 * @desc    Get single category by ID
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/categories/:id',
  param('id').isUUID(),
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const organizationId = req.organizationId;
      const { id } = req.params;

      const [rows] = await pool.query(
        `SELECT 
          c.id,
          c.name,
          c.description,
          c.parent_id,
          c.created_at,
          c.updated_at,
          c.organization_id,
          pc.name as parent_name,
          (
            SELECT COUNT(*) FROM categories 
            WHERE parent_id = c.id AND organization_id = ?
          ) as child_count,
          (
            SELECT COUNT(*) FROM products 
            WHERE category_id = c.id AND organization_id = ?
          ) as product_count
         FROM categories c
         LEFT JOIN categories pc ON c.parent_id = pc.id AND pc.organization_id = ?
         WHERE c.id = ? AND c.organization_id = ?`,
        [organizationId, organizationId, organizationId, id, organizationId]
      );

      if (rows.length === 0) {
        return res.status(404).json({ error: 'Category not found' });
      }

      // Get child categories
      const [children] = await pool.query(
        `SELECT id, name, description, created_at 
         FROM categories 
         WHERE parent_id = ? AND organization_id = ?
         ORDER BY name`,
        [id, organizationId]
      );

      const category = rows[0];
      category.children = children;

      // Get full path to root
      const path = [];
      let currentId = category.parent_id;
      while (currentId) {
        const [parent] = await pool.query(
          'SELECT id, name FROM categories WHERE id = ? AND organization_id = ?',
          [currentId, organizationId]
        );
        if (parent.length > 0) {
          path.unshift({ id: parent[0].id, name: parent[0].name });
          currentId = parent[0].parent_id;
        } else {
          break;
        }
      }
      category.path = path;

      res.json(category);
    } catch (error) {
      console.error('Get category error:', error);
      res.status(500).json({ error: 'Failed to fetch category' });
    }
  }
);

/**
 * @route   POST /api/products/categories
 * @desc    Create new category
 * @access  Private (MANAGE_CATEGORIES permission required)
 */
router.post('/categories',
  validateCategory,
  hasPermission(['MANAGE_CATEGORIES']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const organizationId = req.organizationId;
      const categoryId = uuidv4();
      const { name, description, parent_id } = req.body;

      // Check if category name already exists in this organization
      const [existing] = await connection.query(
        'SELECT id FROM categories WHERE name = ? AND organization_id = ?',
        [name, organizationId]
      );

      if (existing.length > 0) {
        await connection.rollback();
        return res.status(400).json({ error: 'Category name already exists' });
      }

      // If parent_id provided, verify it exists and belongs to same organization
      if (parent_id) {
        const [parent] = await connection.query(
          'SELECT id FROM categories WHERE id = ? AND organization_id = ?',
          [parent_id, organizationId]
        );
        if (parent.length === 0) {
          await connection.rollback();
          return res.status(400).json({ error: 'Parent category not found' });
        }
      }

      // Insert category with all fields
      await connection.query(
        `INSERT INTO categories (
          id, 
          organization_id, 
          name, 
          description, 
          parent_id, 
          created_at, 
          updated_at
        ) VALUES (?, ?, ?, ?, ?, NOW(), NOW())`,
        [
          categoryId, 
          organizationId, 
          name, 
          description || null, 
          parent_id || null
        ]
      );

      // Log action to audit_logs (schema: id auto, user_id, action, table_name, record_id)
      await connection.query(
        `INSERT INTO audit_logs (user_id, action, table_name, record_id, created_at)
         VALUES (?, ?, 'categories', ?, NOW())`,
        [req.user.sub, 'CREATE', categoryId]
      );

      await connection.commit();

      // Fetch the created category to return
      const [newCategory] = await pool.query(
        `SELECT 
          id, name, description, parent_id, organization_id,
          created_at, updated_at
         FROM categories WHERE id = ?`,
        [categoryId]
      );

      res.status(201).json({
        message: 'Category created successfully',
        category: newCategory[0]
      });
    } catch (error) {
      await connection.rollback();
      console.error('Create category error:', error);
      res.status(500).json({ error: 'Failed to create category' });
    } finally {
      connection.release();
    }
  }
);

/**
 * @route   PUT /api/products/categories/:id
 * @desc    Update category
 * @access  Private (MANAGE_CATEGORIES permission required)
 */
router.put('/categories/:id',
  param('id').isUUID(),
  validateCategory,
  hasPermission(['MANAGE_CATEGORIES']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const organizationId = req.organizationId;
      const { id } = req.params;
      const { name, description, parent_id } = req.body;

      // Check if category exists and belongs to this organization
      const [existing] = await connection.query(
        'SELECT * FROM categories WHERE id = ? AND organization_id = ?',
        [id, organizationId]
      );

      if (existing.length === 0) {
        await connection.rollback();
        return res.status(404).json({ error: 'Category not found' });
      }

      const existingCategory = existing[0];

      // Check if new name conflicts with another category
      if (name && name !== existingCategory.name) {
        const [nameCheck] = await connection.query(
          'SELECT id FROM categories WHERE name = ? AND organization_id = ? AND id != ?',
          [name, organizationId, id]
        );
        if (nameCheck.length > 0) {
          await connection.rollback();
          return res.status(400).json({ error: 'Category name already exists' });
        }
      }

      // If parent_id is being changed
      if (parent_id !== undefined && parent_id !== existingCategory.parent_id) {
        // Check if trying to set parent to itself
        if (parent_id === id) {
          await connection.rollback();
          return res.status(400).json({ error: 'Category cannot be its own parent' });
        }

        // If parent_id is provided (not null), verify it exists
        if (parent_id) {
          const [parent] = await connection.query(
            'SELECT id FROM categories WHERE id = ? AND organization_id = ?',
            [parent_id, organizationId]
          );
          if (parent.length === 0) {
            await connection.rollback();
            return res.status(400).json({ error: 'Parent category not found' });
          }

          // Check for circular reference
          const [circular] = await connection.query(
            `WITH RECURSIVE category_path AS (
              SELECT id, parent_id FROM categories WHERE id = ?
              UNION ALL
              SELECT c.id, c.parent_id FROM categories c
              INNER JOIN category_path cp ON c.id = cp.parent_id
            )
            SELECT * FROM category_path WHERE id = ?`,
            [parent_id, id]
          );

          if (circular.length > 0) {
            await connection.rollback();
            return res.status(400).json({ error: 'Circular reference detected in category hierarchy' });
          }
        }
      }

      // Build update query dynamically based on provided fields
      const updates = [];
      const params = [];

      if (name !== undefined) {
        updates.push('name = ?');
        params.push(name);
      }
      if (description !== undefined) {
        updates.push('description = ?');
        params.push(description || null);
      }
      if (parent_id !== undefined) {
        updates.push('parent_id = ?');
        params.push(parent_id || null);
      }
      
      updates.push('updated_at = NOW()');

      if (updates.length > 1) { // More than just updated_at
        params.push(id, organizationId);
        
        await connection.query(
          `UPDATE categories SET ${updates.join(', ')} 
           WHERE id = ? AND organization_id = ?`,
          params
        );
      }

      // Log action to audit_logs (schema: id, user_id, action, table_name, record_id, created_at)
      await connection.query(
        `INSERT INTO audit_logs (id, user_id, action, table_name, record_id, created_at)
         VALUES (?, ?, ?, ?, ?, NOW())`,
        [uuidv4(), req.user.sub, 'UPDATE', 'categories', id]
      );

      await connection.commit();

      // Fetch the updated category
      const [updatedCategory] = await pool.query(
        `SELECT 
          id, name, description, parent_id, organization_id,
          created_at, updated_at
         FROM categories WHERE id = ?`,
        [id]
      );

      res.json({
        message: 'Category updated successfully',
        category: updatedCategory[0]
      });
    } catch (error) {
      await connection.rollback();
      console.error('Update category error:', error);
      res.status(500).json({ error: 'Failed to update category' });
    } finally {
      connection.release();
    }
  }
);

/**
 * @route   DELETE /api/products/categories/:id
 * @desc    Delete category
 * @access  Private (MANAGE_CATEGORIES permission required)
 */
router.delete('/categories/:id',
  param('id').isUUID(),
  hasPermission(['MANAGE_CATEGORIES']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const organizationId = req.organizationId;
      const { id } = req.params;

      // Check if category exists and belongs to this organization
      const [category] = await connection.query(
        'SELECT * FROM categories WHERE id = ? AND organization_id = ?',
        [id, organizationId]
      );

      if (category.length === 0) {
        await connection.rollback();
        return res.status(404).json({ error: 'Category not found' });
      }

      // Check if category has child categories
      const [childCount] = await connection.query(
        'SELECT COUNT(*) as count FROM categories WHERE parent_id = ?',
        [id]
      );

      if (childCount[0].count > 0) {
        await connection.rollback();
        return res.status(400).json({ 
          error: 'Cannot delete category with subcategories. Reassign or delete subcategories first.' 
        });
      }

      // Check if category has products
      const [productCount] = await connection.query(
        'SELECT COUNT(*) as count FROM products WHERE category_id = ?',
        [id]
      );

      if (productCount[0].count > 0) {
        await connection.rollback();
        return res.status(400).json({ 
          error: 'Cannot delete category with existing products. Reassign products first.' 
        });
      }

      // Delete the category
      await connection.query(
        'DELETE FROM categories WHERE id = ? AND organization_id = ?',
        [id, organizationId]
      );

      // Log action to audit_logs (schema: id auto, user_id, action, table_name, record_id)
      await connection.query(
        `INSERT INTO audit_logs (user_id, action, table_name, record_id, created_at)
         VALUES (?, ?, 'categories', ?, NOW())`,
        [req.user.sub, 'DELETE', id]
      );

      await connection.commit();

      res.json({ 
        message: 'Category deleted successfully',
        deletedCategory: {
          id: category[0].id,
          name: category[0].name
        }
      });
    } catch (error) {
      await connection.rollback();
      console.error('Delete category error:', error);
      res.status(500).json({ error: 'Failed to delete category' });
    } finally {
      connection.release();
    }
  }
);

// ==================== BRAND ROUTES ====================

/**
 * @route   GET /api/products/brands/list
 * @desc    List all brands
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/brands/list',
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
      const organizationId = req.organizationId;

      const [rows] = await pool.query(
        `SELECT b.*, COUNT(p.id) as product_count
         FROM brands b
         LEFT JOIN products p ON b.id = p.brand_id AND p.organization_id = ? AND p.is_active = 1
         WHERE b.organization_id = ?
         GROUP BY b.id
         ORDER BY b.name`,
        [organizationId, organizationId]
      );

      res.json(rows);
    } catch (error) {
      console.error('List brands error:', error);
      res.status(500).json({ error: 'Failed to fetch brands' });
    }
  }
);

/**
 * @route   POST /api/products/brands
 * @desc    Create new brand
 * @access  Private (MANAGE_BRANDS permission required)
 */
router.post('/brands',
  validateBrand,
  hasPermission(['MANAGE_BRANDS']),
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const organizationId = req.organizationId;
      const brandId = uuidv4();
      const { name, description } = req.body;

      // Check if brand name already exists
      const [existing] = await pool.query(
        'SELECT id FROM brands WHERE name = ? AND organization_id = ?',
        [name, organizationId]
      );

      if (existing.length > 0) {
        return res.status(400).json({ error: 'Brand name already exists' });
      }

      await pool.query(
        `INSERT INTO brands (id, organization_id, name, description, created_at, updated_at)
         VALUES (?, ?, ?, ?, NOW(), NOW())`,
        [brandId, organizationId, name, description || null]
      );

      // Log action
      await pool.query(
        `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          organizationId,
          'CREATE',
          'brand',
          brandId,
          JSON.stringify({ name })
        ]
      );

      res.status(201).json({
        message: 'Brand created successfully',
        brandId
      });
    } catch (error) {
      console.error('Create brand error:', error);
      res.status(500).json({ error: 'Failed to create brand' });
    }
  }
);

/**
 * @route   PUT /api/products/brands/:id
 * @desc    Update brand
 * @access  Private (MANAGE_BRANDS permission required)
 */
router.put('/brands/:id',
  param('id').isUUID(),
  validateBrand,
  hasPermission(['MANAGE_BRANDS']),
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const organizationId = req.organizationId;
      const { id } = req.params;
      const { name, description } = req.body;

      // Check if brand exists
      const [existing] = await pool.query(
        'SELECT * FROM brands WHERE id = ? AND organization_id = ?',
        [id, organizationId]
      );

      if (existing.length === 0) {
        return res.status(404).json({ error: 'Brand not found' });
      }

      // Check if new name conflicts with another brand
      if (name && name !== existing[0].name) {
        const [nameCheck] = await pool.query(
          'SELECT id FROM brands WHERE name = ? AND organization_id = ? AND id != ?',
          [name, organizationId, id]
        );
        if (nameCheck.length > 0) {
          return res.status(400).json({ error: 'Brand name already exists' });
        }
      }

      await pool.query(
        `UPDATE brands SET name = ?, description = ?, updated_at = NOW()
         WHERE id = ? AND organization_id = ?`,
        [name, description || null, id, organizationId]
      );

      // Log action
      await pool.query(
        `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          organizationId,
          'UPDATE',
          'brand',
          id,
          JSON.stringify({ name, description })
        ]
      );

      res.json({ message: 'Brand updated successfully' });
    } catch (error) {
      console.error('Update brand error:', error);
      res.status(500).json({ error: 'Failed to update brand' });
    }
  }
);

/**
 * @route   DELETE /api/products/brands/:id
 * @desc    Delete brand
 * @access  Private (MANAGE_BRANDS permission required)
 */
router.delete('/brands/:id',
  param('id').isUUID(),
  hasPermission(['MANAGE_BRANDS']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const organizationId = req.organizationId;
      const { id } = req.params;

      // Check if brand has products
      const [productCount] = await connection.query(
        'SELECT COUNT(*) as count FROM products WHERE brand_id = ?',
        [id]
      );

      if (productCount[0].count > 0) {
        await connection.rollback();
        return res.status(400).json({ 
          error: 'Cannot delete brand with existing products. Reassign products first.' 
        });
      }

      await connection.query(
        'DELETE FROM brands WHERE id = ? AND organization_id = ?',
        [id, organizationId]
      );

      // Log action
      await connection.query(
        `INSERT INTO audit_logs (id, user_id, organization_id, action, entity_type, entity_id, details, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          organizationId,
          'DELETE',
          'brand',
          id,
          JSON.stringify({ deleted: true })
        ]
      );

      await connection.commit();

      res.json({ message: 'Brand deleted successfully' });
    } catch (error) {
      await connection.rollback();
      console.error('Delete brand error:', error);
      res.status(500).json({ error: 'Failed to delete brand' });
    } finally {
      connection.release();
    }
  }
);

// ==================== UNIT ROUTES ====================

/**
 * @route   GET /api/products/units/list
 * @desc    List all units
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/units/list',
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM units ORDER BY name'
      );
      res.json(rows);
    } catch (error) {
      console.error('List units error:', error);
      res.status(500).json({ error: 'Failed to fetch units' });
    }
  }
);

/**
 * @route   GET /api/products/units/:id
 * @desc    Get single unit by ID
 * @access  Private (VIEW_PRODUCTS permission required)
 */
router.get('/units/:id',
  param('id').isUUID(),
  hasPermission(['VIEW_PRODUCTS']),
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { id } = req.params;

      const [rows] = await pool.query(
        'SELECT * FROM units WHERE id = ?',
        [id]
      );

      if (rows.length === 0) {
        return res.status(404).json({ error: 'Unit not found' });
      }

      // Get product count using this unit
      const [productCount] = await pool.query(
        'SELECT COUNT(*) as count FROM products WHERE unit_id = ?',
        [id]
      );

      const unit = rows[0];
      unit.product_count = productCount[0].count;

      res.json(unit);
    } catch (error) {
      console.error('Get unit error:', error);
      res.status(500).json({ error: 'Failed to fetch unit' });
    }
  }
);

/**
 * @route   POST /api/products/units
 * @desc    Create new unit
 * @access  Private (MANAGE_UNITS permission required) - You may need to add this permission
 */
router.post('/units',
  [
    body('name').notEmpty().trim().escape(),
    body('abbreviation').notEmpty().trim().escape(),
    body('description').optional().trim().escape(),
  ],
  hasPermission(['MANAGE_PRODUCTS']), // Or create MANAGE_UNITS permission
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const unitId = uuidv4();
      const { name, abbreviation, description } = req.body;

      // Check if unit name already exists
      const [existing] = await connection.query(
        'SELECT id FROM units WHERE name = ?',
        [name]
      );

      if (existing.length > 0) {
        await connection.rollback();
        return res.status(400).json({ error: 'Unit name already exists' });
      }

      // Check if abbreviation already exists
      const [existingAbbr] = await connection.query(
        'SELECT id FROM units WHERE abbreviation = ?',
        [abbreviation]
      );

      if (existingAbbr.length > 0) {
        await connection.rollback();
        return res.status(400).json({ error: 'Unit abbreviation already exists' });
      }

      await connection.query(
        `INSERT INTO units (
          id, name, abbreviation, description, created_at, updated_at
        ) VALUES (?, ?, ?, ?, NOW(), NOW())`,
        [unitId, name, abbreviation, description || null]
      );

      // Log action
      await connection.query(
        `INSERT INTO audit_logs (
          id, user_id, action, entity_type, entity_id, details, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          'CREATE',
          'unit',
          unitId,
          JSON.stringify({ name, abbreviation })
        ]
      );

      await connection.commit();

      res.status(201).json({
        message: 'Unit created successfully',
        unitId
      });
    } catch (error) {
      await connection.rollback();
      console.error('Create unit error:', error);
      res.status(500).json({ error: 'Failed to create unit' });
    } finally {
      connection.release();
    }
  }
);

/**
 * @route   PUT /api/products/units/:id
 * @desc    Update unit
 * @access  Private (MANAGE_UNITS permission required)
 */
router.put('/units/:id',
  param('id').isUUID(),
  [
    body('name').optional().trim().escape(),
    body('abbreviation').optional().trim().escape(),
    body('description').optional().trim().escape(),
  ],
  hasPermission(['MANAGE_PRODUCTS']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const { id } = req.params;
      const { name, abbreviation, description } = req.body;

      // Check if unit exists
      const [existing] = await connection.query(
        'SELECT * FROM units WHERE id = ?',
        [id]
      );

      if (existing.length === 0) {
        await connection.rollback();
        return res.status(404).json({ error: 'Unit not found' });
      }

      // Check if new name conflicts with another unit
      if (name && name !== existing[0].name) {
        const [nameCheck] = await connection.query(
          'SELECT id FROM units WHERE name = ? AND id != ?',
          [name, id]
        );
        if (nameCheck.length > 0) {
          await connection.rollback();
          return res.status(400).json({ error: 'Unit name already exists' });
        }
      }

      // Check if new abbreviation conflicts with another unit
      if (abbreviation && abbreviation !== existing[0].abbreviation) {
        const [abbrCheck] = await connection.query(
          'SELECT id FROM units WHERE abbreviation = ? AND id != ?',
          [abbreviation, id]
        );
        if (abbrCheck.length > 0) {
          await connection.rollback();
          return res.status(400).json({ error: 'Unit abbreviation already exists' });
        }
      }

      // Build update query
      const updates = [];
      const params = [];

      if (name !== undefined) {
        updates.push('name = ?');
        params.push(name);
      }
      if (abbreviation !== undefined) {
        updates.push('abbreviation = ?');
        params.push(abbreviation);
      }
      if (description !== undefined) {
        updates.push('description = ?');
        params.push(description || null);
      }
      
      updates.push('updated_at = NOW()');

      if (updates.length > 1) {
        params.push(id);
        
        await connection.query(
          `UPDATE units SET ${updates.join(', ')} WHERE id = ?`,
          params
        );
      }

      // Log action
      await connection.query(
        `INSERT INTO audit_logs (
          id, user_id, action, entity_type, entity_id, details, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          'UPDATE',
          'unit',
          id,
          JSON.stringify({ name, abbreviation, description })
        ]
      );

      await connection.commit();

      res.json({ message: 'Unit updated successfully' });
    } catch (error) {
      await connection.rollback();
      console.error('Update unit error:', error);
      res.status(500).json({ error: 'Failed to update unit' });
    } finally {
      connection.release();
    }
  }
);

/**
 * @route   DELETE /api/products/units/:id
 * @desc    Delete unit
 * @access  Private (MANAGE_UNITS permission required)
 */
router.delete('/units/:id',
  param('id').isUUID(),
  hasPermission(['MANAGE_PRODUCTS']),
  async (req, res) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const { id } = req.params;

      // Check if unit exists
      const [unit] = await connection.query(
        'SELECT * FROM units WHERE id = ?',
        [id]
      );

      if (unit.length === 0) {
        await connection.rollback();
        return res.status(404).json({ error: 'Unit not found' });
      }

      // Check if unit is used by any products
      const [productCount] = await connection.query(
        'SELECT COUNT(*) as count FROM products WHERE unit_id = ?',
        [id]
      );

      if (productCount[0].count > 0) {
        await connection.rollback();
        return res.status(400).json({ 
          error: 'Cannot delete unit that is used by products. Reassign products first.' 
        });
      }

      await connection.query(
        'DELETE FROM units WHERE id = ?',
        [id]
      );

      // Log action
      await connection.query(
        `INSERT INTO audit_logs (
          id, user_id, action, entity_type, entity_id, details, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          req.user.sub,
          'DELETE',
          'unit',
          id,
          JSON.stringify({ name: unit[0].name })
        ]
      );

      await connection.commit();

      res.json({ message: 'Unit deleted successfully' });
    } catch (error) {
      await connection.rollback();
      console.error('Delete unit error:', error);
      res.status(500).json({ error: 'Failed to delete unit' });
    } finally {
      connection.release();
    }
  }
);

export default router;