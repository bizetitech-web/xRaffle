import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import pool, { testConnection } from './config/database.js';
import authRoutes from './routes/authRoutes.js';
import dashboardRoutes from './routes/dashboardRoutes.js';
// Import admin routes
import adminRoutes from './routes/adminRoutes.js';
import productRoutes from './routes/productRoutes.js';

// Get directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load environment variables from server folder
dotenv.config({ path: join(__dirname, '.env') });

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: ['http://localhost:3000', 'https://tradeflow.bizetcode.com'],
  credentials: true
}));
app.use(express.json());

// ✅ Serve static files from the client folder (React build)
app.use(express.static(join(__dirname, '../client')));

// Test database connection on startup
testConnection();

// Add admin routes
app.use('/api/admin', adminRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date(),
    env: process.env.NODE_ENV || 'development'
  });
});

// Database status with more details
app.get('/api/db-status', async (req, res) => {
  try {
    const connection = await pool.getConnection();
    
    const [tables] = await connection.query(
      "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = ?",
      [process.env.DB_NAME]
    );
    
    const [orgCount] = await connection.query(
      'SELECT COUNT(*) as count FROM organizations'
    );
    
    connection.release();
    
    res.json({ 
      status: 'connected',
      database: process.env.DB_NAME,
      tables: tables.map(t => t.TABLE_NAME),
      organizationsCount: orgCount[0].count,
      timestamp: new Date()
    });
  } catch (error) {
    console.error('Database status error:', error);
    res.status(500).json({ 
      status: 'disconnected', 
      error: error.message,
      code: error.code
    });
  }
});

// Auth routes
app.use('/api/auth', authRoutes);
// Dashboard routes
app.use('/api/dashboard', dashboardRoutes);

// Get test messages (using organizations table)
app.get('/api/test-messages', async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id, name, created_at FROM organizations ORDER BY created_at DESC LIMIT 10'
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ 
      error: error.message,
      sqlMessage: error.sqlMessage 
    });
  }
});

// Add test message
app.post('/api/test-messages', async (req, res) => {
  const { message } = req.body;
  try {
    const [result] = await pool.query(
      'INSERT INTO organizations (name, email, status, created_at) VALUES (?, ?, ?, NOW())',
      [message, `test-${Date.now()}@example.com`, 'active']
    );
    
    const [newRecord] = await pool.query(
      'SELECT id, name, created_at FROM organizations WHERE id = ?',
      [result.insertId]
    );
    
    res.json({ 
      id: newRecord[0].id, 
      message: newRecord[0].name,
      created_at: newRecord[0].created_at 
    });
  } catch (error) {
    console.error('Error inserting message:', error);
    res.status(500).json({ 
      error: error.message,
      sqlMessage: error.sqlMessage 
    });
  }
});

// Diagnostic endpoint
app.get('/api/db-diagnostic', async (req, res) => {
  const results = {
    environment: {
      DB_HOST: process.env.DB_HOST,
      DB_USER: process.env.DB_USER,
      DB_NAME: process.env.DB_NAME,
      PORT: process.env.PORT
    }
  };
  
  try {
    const connection = await pool.getConnection();
    results.connection = 'OK';
    
    const [tables] = await connection.query('SHOW TABLES');
    results.tables = tables.map(t => Object.values(t)[0]);
    
    try {
      const [orgColumns] = await connection.query('DESCRIBE organizations');
      results.organizations = {
        exists: true,
        columns: orgColumns.map(c => c.Field)
      };
      
      const [sampleData] = await connection.query('SELECT * FROM organizations LIMIT 3');
      results.sampleData = sampleData;
      
    } catch (e) {
      results.organizations = {
        exists: false,
        error: e.message
      };
    }
    
    connection.release();
    res.json(results);
    
  } catch (error) {
    res.status(500).json({
      error: error.message,
      code: error.code,
      results: results
    });
  }
});

app.use('/api/products', productRoutes);  // This adds '/products' prefix to all routes

// ✅ IMPORTANT: This catch-all route MUST come AFTER all API routes
// It handles client-side routing by serving index.html for any non-API routes
app.get('*', (req, res) => {
  // Don't serve index.html for API routes (they should have been handled above)
  if (!req.path.startsWith('/api')) {
    const indexPath = join(__dirname, '../client/index.html');
    console.log(`📄 Serving index.html for: ${req.path}`);
    res.sendFile(indexPath);
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📁 Serving static files from: ${join(__dirname, '../client')}`);
  console.log(`📁 Environment file: ${join(__dirname, '.env')}`);
  console.log(`🔍 Test endpoints:`);
  console.log(`   - Health: http://localhost:${PORT}/api/health`);
  console.log(`   - DB Status: http://localhost:${PORT}/api/db-status`);
  console.log(`   - Diagnostic: http://localhost:${PORT}/api/db-diagnostic`);
  console.log(`   - React app: http://localhost:${PORT}/ (should serve index.html)`);
});