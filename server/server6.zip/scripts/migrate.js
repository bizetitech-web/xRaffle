import pool from '../config/database.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runMigration() {
  try {
    console.log('🔄 Running database migration...');
    
    // Read the SQL file
    const sqlPath = path.join(__dirname, '../database/add_missing_fields.sql');
    const sql = fs.readFileSync(sqlPath, 'utf8');
    
    // Split into individual statements
    const statements = sql.split(';').filter(stmt => stmt.trim());
    
    // Execute each statement
    for (let stmt of statements) {
      if (stmt.trim()) {
        try {
          await pool.query(stmt);
          console.log('✅ Executed:', stmt.substring(0, 50) + '...');
        } catch (err) {
          console.error('❌ Error executing:', stmt.substring(0, 50));
          console.error(err.message);
        }
      }
    }
    
    console.log('✅ Migration completed successfully!');
  } catch (error) {
    console.error('❌ Migration failed:', error);
  } finally {
    await pool.end();
    process.exit();
  }
}

runMigration();