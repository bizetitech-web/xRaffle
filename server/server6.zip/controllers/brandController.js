export const listBrands = (req, res) => res.json([]);
export const createBrand = (req, res) => res.status(201).json(req.body);
