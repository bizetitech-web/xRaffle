import pool from '../config/database.js';

export const getDashboardStats = async (req, res) => {
  try {
    const organizationId = req.organizationId;

    // Get total products
    const [products] = await pool.query(
      'SELECT COUNT(*) as count FROM products WHERE organization_id = ? AND is_active = 1',
      [organizationId]
    );

    // Get low stock products
    const [lowStock] = await pool.query(
      `SELECT COUNT(*) as count FROM products 
       WHERE organization_id = ? AND is_active = 1 
       AND current_stock <= min_stock_level`,
      [organizationId]
    );

    // Get total customers
    const [customers] = await pool.query(
      'SELECT COUNT(*) as count FROM customers WHERE organization_id = ?',
      [organizationId]
    );

    // Get today's sales
    const [todaySales] = await pool.query(
      `SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total 
       FROM sales 
       WHERE organization_id = ? AND DATE(created_at) = CURDATE()`,
      [organizationId]
    );

    // Get monthly sales
    const [monthlySales] = await pool.query(
      `SELECT COUNT(*) as count, COALESCE(SUM(total_amount), 0) as total 
       FROM sales 
       WHERE organization_id = ? 
       AND MONTH(created_at) = MONTH(CURDATE()) 
       AND YEAR(created_at) = YEAR(CURDATE())`,
      [organizationId]
    );

    // Get recent activities
    const [recentActivities] = await pool.query(
      `SELECT 
        al.id,
        al.action,
        al.entity_type as type,
        al.created_at as time,
        u.name as user,
        u.first_name,
        u.last_name
       FROM audit_logs al
       LEFT JOIN users u ON al.user_id = u.id
       WHERE al.organization_id = ?
       ORDER BY al.created_at DESC
       LIMIT 10`,
      [organizationId]
    );

    // Get low stock items detail
    const [lowStockItems] = await pool.query(
      `SELECT 
        p.id, p.name, p.sku, 
        p.current_stock as stock, 
        p.min_stock_level as minStock,
        c.name as category_name,
        b.name as brand_name,
        ROUND((p.current_stock / NULLIF(p.min_stock_level, 0) * 100), 1) as percentage
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       LEFT JOIN brands b ON p.brand_id = b.id
       WHERE p.organization_id = ? 
         AND p.is_active = 1
         AND p.current_stock <= p.min_stock_level
       ORDER BY (p.current_stock / NULLIF(p.min_stock_level, 0)) ASC
       LIMIT 5`,
      [organizationId]
    );

    // Get top selling products
    const [topProducts] = await pool.query(
      `SELECT 
        p.id, p.name, p.sku,
        COUNT(si.id) as sale_count,
        SUM(si.quantity) as total_sold,
        SUM(si.subtotal) as revenue
       FROM products p
       LEFT JOIN sale_items si ON p.id = si.product_id
       LEFT JOIN sales s ON si.sale_id = s.id
       WHERE p.organization_id = ? 
         AND p.is_active = 1
         AND s.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       GROUP BY p.id
       ORDER BY total_sold DESC
       LIMIT 5`,
      [organizationId]
    );

    // Get inventory value
    const [inventoryValue] = await pool.query(
      `SELECT 
        COALESCE(SUM(current_stock * cost_price), 0) as cost_value,
        COALESCE(SUM(current_stock * selling_price), 0) as retail_value
       FROM products 
       WHERE organization_id = ? AND is_active = 1`,
      [organizationId]
    );

    // Get recent orders
    const [recentOrders] = await pool.query(
      `SELECT 
        s.id, s.invoice_number, s.total_amount,
        s.status, s.created_at,
        c.name as customer_name
       FROM sales s
       LEFT JOIN customers c ON s.customer_id = c.id
       WHERE s.organization_id = ?
       ORDER BY s.created_at DESC
       LIMIT 5`,
      [organizationId]
    );

    // Format activities
    const formattedActivities = recentActivities.map(activity => ({
      id: activity.id,
      action: activity.action,
      type: activity.type,
      time: formatTimeAgo(activity.time),
      user: activity.first_name 
        ? `${activity.first_name} ${activity.last_name || ''}`.trim()
        : activity.user || 'System',
    }));

    res.json({
      summary: {
        totalProducts: products[0].count,
        lowStock: lowStock[0].count,
        totalCustomers: customers[0].count,
        todaySales: todaySales[0].total,
        todayOrders: todaySales[0].count,
        monthlySales: monthlySales[0].total,
        monthlyOrders: monthlySales[0].count,
        inventoryValue: inventoryValue[0].retail_value,
        inventoryCost: inventoryValue[0].cost_value,
      },
      lowStockItems: lowStockItems.map(item => ({
        ...item,
        percentage: Math.min(100, Math.max(0, parseFloat(item.percentage) || 0))
      })),
      topProducts,
      recentActivities: formattedActivities,
      recentOrders,
      timestamp: new Date()
    });

  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard stats' });
  }
};

export const getInventoryChart = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const { period = '30days' } = req.query;

    let interval;
    let format;

    switch(period) {
      case '7days':
        interval = 7;
        format = '%Y-%m-%d';
        break;
      case '30days':
        interval = 30;
        format = '%Y-%m-%d';
        break;
      case '12months':
        interval = 12;
        format = '%Y-%m';
        break;
      default:
        interval = 30;
        format = '%Y-%m-%d';
    }

    // Get inventory movements over time
    const [movements] = await pool.query(
      `SELECT 
        DATE_FORMAT(created_at, ?) as date,
        SUM(CASE WHEN quantity > 0 THEN quantity ELSE 0 END) as stock_in,
        SUM(CASE WHEN quantity < 0 THEN ABS(quantity) ELSE 0 END) as stock_out
       FROM inventory_movements
       WHERE organization_id = ? 
         AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
       GROUP BY DATE_FORMAT(created_at, ?)
       ORDER BY date ASC`,
      [format, organizationId, interval, format]
    );

    // Get sales over time
    const [sales] = await pool.query(
      `SELECT 
        DATE_FORMAT(created_at, ?) as date,
        COUNT(*) as order_count,
        COALESCE(SUM(total_amount), 0) as revenue
       FROM sales
       WHERE organization_id = ? 
         AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
       GROUP BY DATE_FORMAT(created_at, ?)
       ORDER BY date ASC`,
      [format, organizationId, interval, format]
    );

    res.json({
      movements,
      sales,
      period
    });

  } catch (error) {
    console.error('Inventory chart error:', error);
    res.status(500).json({ error: 'Failed to fetch chart data' });
  }
};

function formatTimeAgo(date) {
  const now = new Date();
  const past = new Date(date);
  const diffInSeconds = Math.floor((now - past) / 1000);

  if (diffInSeconds < 60) return 'just now';
  if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} minutes ago`;
  if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
  if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)} days ago`;
  return past.toLocaleDateString();
}