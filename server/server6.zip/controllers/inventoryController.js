import pool from '../config/database.js';
import { v4 as uuidv4 } from 'uuid';

// ==================== CONTAINERS ====================

/**
 * Get all containers with pagination and filters
 */
export const getContainers = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const {
      page = 1,
      limit = 20,
      search = '',
      status,
      sortBy = 'created_at',
      sortOrder = 'DESC'
    } = req.query;

    const offset = (page - 1) * limit;

    // Build query
    let query = `
      SELECT 
        c.*,
        COUNT(ci.id) as item_count,
        SUM(ci.quantity) as total_items,
        COUNT(DISTINCT CASE WHEN ci.arrival_date IS NULL THEN ci.id END) as pending_items
      FROM containers c
      LEFT JOIN container_items ci ON c.id = ci.container_id
      WHERE c.organization_id = ?
    `;
    
    const queryParams = [organizationId];

    // Add search filter
    if (search) {
      query += ` AND (c.container_number LIKE ? OR c.reference_number LIKE ? OR c.carrier LIKE ?)`;
      const searchTerm = `%${search}%`;
      queryParams.push(searchTerm, searchTerm, searchTerm);
    }

    // Add status filter
    if (status) {
      query += ` AND c.status = ?`;
      queryParams.push(status);
    }

    // Group by container
    query += ` GROUP BY c.id`;

    // Get total count
    const countQuery = `SELECT COUNT(*) as total FROM (${query}) as countTable`;
    const [countResult] = await pool.query(countQuery, queryParams);
    const total = countResult[0].total;

    // Add sorting and pagination
    const validSortColumns = ['container_number', 'status', 'expected_date', 'arrival_date', 'created_at'];
    const sortColumn = validSortColumns.includes(sortBy) ? sortBy : 'created_at';
    const order = sortOrder.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';
    
    query += ` ORDER BY c.${sortColumn} ${order} LIMIT ? OFFSET ?`;
    queryParams.push(parseInt(limit), parseInt(offset));

    const [rows] = await pool.query(query, queryParams);

    res.json({
      containers: rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get containers error:', error);
    res.status(500).json({ error: 'Failed to fetch containers' });
  }
};

/**
 * Get single container by ID
 */
export const getContainerById = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const { id } = req.params;

    const [containerRows] = await pool.query(
      `SELECT * FROM containers 
       WHERE id = ? AND organization_id = ?`,
      [id, organizationId]
    );

    if (containerRows.length === 0) {
      return res.status(404).json({ error: 'Container not found' });
    }

    const container = containerRows[0];

    // Get container items with product details
    const [items] = await pool.query(
      `SELECT 
        ci.*,
        p.name as product_name,
        p.sku as product_sku,
        p.selling_price,
        p.unit_id,
        u.name as unit_name
       FROM container_items ci
       LEFT JOIN products p ON ci.product_id = p.id
       LEFT JOIN units u ON p.unit_id = u.id
       WHERE ci.container_id = ?
       ORDER BY ci.created_at DESC`,
      [id]
    );

    container.items = items;

    // Get movement history
    const [movements] = await pool.query(
      `SELECT 
        im.*,
        u.name as user_name,
        p.name as product_name
       FROM inventory_movements im
       LEFT JOIN users u ON im.created_by = u.id
       LEFT JOIN products p ON im.product_id = p.id
       WHERE im.container_id = ?
       ORDER BY im.created_at DESC
       LIMIT 20`,
      [id]
    );

    container.movements = movements;

    res.json(container);
  } catch (error) {
    console.error('Get container error:', error);
    res.status(500).json({ error: 'Failed to fetch container' });
  }
};

/**
 * Create new container
 */
export const createContainer = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const containerId = uuidv4();
    const {
      container_number,
      reference_number,
      carrier,
      expected_date,
      arrival_date,
      notes,
      status = 'in_transit'
    } = req.body;

    // Validate required fields
    if (!container_number) {
      await connection.rollback();
      return res.status(400).json({ error: 'Container number is required' });
    }

    // Check if container number already exists
    const [existing] = await connection.query(
      'SELECT id FROM containers WHERE container_number = ? AND organization_id = ?',
      [container_number, organizationId]
    );

    if (existing.length > 0) {
      await connection.rollback();
      return res.status(400).json({ error: 'Container number already exists' });
    }

    await connection.query(
      `INSERT INTO containers (
        id, organization_id, container_number, reference_number,
        carrier, expected_date, arrival_date, notes, status,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [
        containerId,
        organizationId,
        container_number,
        reference_number || null,
        carrier || null,
        expected_date || null,
        arrival_date || null,
        notes || null,
        status
      ]
    );

    // Log in audit trail
    await connection.query(
      `INSERT INTO audit_logs (
        id, user_id, organization_id, action, entity_type, entity_id, details, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'CREATE',
        'container',
        containerId,
        JSON.stringify({ container_number, status })
      ]
    );

    await connection.commit();

    res.status(201).json({
      message: 'Container created successfully',
      containerId
    });
  } catch (error) {
    await connection.rollback();
    console.error('Create container error:', error);
    res.status(500).json({ error: 'Failed to create container' });
  } finally {
    connection.release();
  }
};

/**
 * Update container
 */
export const updateContainer = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const { id } = req.params;
    const {
      container_number,
      reference_number,
      carrier,
      expected_date,
      arrival_date,
      notes,
      status
    } = req.body;

    // Check if container exists
    const [existing] = await connection.query(
      'SELECT * FROM containers WHERE id = ? AND organization_id = ?',
      [id, organizationId]
    );

    if (existing.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: 'Container not found' });
    }

    // Check if container number already exists (if changed)
    if (container_number && container_number !== existing[0].container_number) {
      const [numberCheck] = await connection.query(
        'SELECT id FROM containers WHERE container_number = ? AND organization_id = ? AND id != ?',
        [container_number, organizationId, id]
      );
      if (numberCheck.length > 0) {
        await connection.rollback();
        return res.status(400).json({ error: 'Container number already exists' });
      }
    }

    await connection.query(
      `UPDATE containers SET
        container_number = ?, reference_number = ?, carrier = ?,
        expected_date = ?, arrival_date = ?, notes = ?, status = ?,
        updated_at = NOW()
       WHERE id = ? AND organization_id = ?`,
      [
        container_number,
        reference_number || null,
        carrier || null,
        expected_date || null,
        arrival_date || null,
        notes || null,
        status,
        id,
        organizationId
      ]
    );

    // If status changed to 'arrived', create arrival record
    if (status === 'arrived' && existing[0].status !== 'arrived') {
      // Log arrival in movements
      await connection.query(
        `INSERT INTO inventory_movements (
          id, organization_id, container_id, type, reference_type,
          reference_id, notes, created_by, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          organizationId,
          id,
          'container_arrival',
          'container',
          id,
          `Container arrived`,
          req.user.sub
        ]
      );
    }

    // Log in audit trail
    await connection.query(
      `INSERT INTO audit_logs (
        id, user_id, organization_id, action, entity_type, entity_id, details, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'UPDATE',
        'container',
        id,
        JSON.stringify({ changes: req.body })
      ]
    );

    await connection.commit();

    res.json({ message: 'Container updated successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Update container error:', error);
    res.status(500).json({ error: 'Failed to update container' });
  } finally {
    connection.release();
  }
};

/**
 * Delete container
 */
export const deleteContainer = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const { id } = req.params;

    // Check if container has items
    const [itemCount] = await connection.query(
      'SELECT COUNT(*) as count FROM container_items WHERE container_id = ?',
      [id]
    );

    if (itemCount[0].count > 0) {
      await connection.rollback();
      return res.status(400).json({ 
        error: 'Cannot delete container with items. Remove items first.' 
      });
    }

    await connection.query(
      'DELETE FROM containers WHERE id = ? AND organization_id = ?',
      [id, organizationId]
    );

    // Log in audit trail
    await connection.query(
      `INSERT INTO audit_logs (
        id, user_id, organization_id, action, entity_type, entity_id, details, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'DELETE',
        'container',
        id,
        JSON.stringify({ deleted: true })
      ]
    );

    await connection.commit();

    res.json({ message: 'Container deleted successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Delete container error:', error);
    res.status(500).json({ error: 'Failed to delete container' });
  } finally {
    connection.release();
  }
};

// ==================== CONTAINER ITEMS ====================

/**
 * Add item to container
 */
export const addContainerItem = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const { containerId } = req.params;
    const {
      product_id,
      quantity,
      unit_price,
      batch_number,
      expiry_date,
      notes
    } = req.body;

    // Validate required fields
    if (!product_id) {
      await connection.rollback();
      return res.status(400).json({ error: 'Product ID is required' });
    }
    if (!quantity || quantity <= 0) {
      await connection.rollback();
      return res.status(400).json({ error: 'Valid quantity is required' });
    }

    // Check if container exists and belongs to org
    const [container] = await connection.query(
      'SELECT id, status FROM containers WHERE id = ? AND organization_id = ?',
      [containerId, organizationId]
    );

    if (container.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: 'Container not found' });
    }

    // Check if product exists
    const [product] = await connection.query(
      'SELECT id, name FROM products WHERE id = ? AND organization_id = ?',
      [product_id, organizationId]
    );

    if (product.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: 'Product not found' });
    }

    const itemId = uuidv4();

    await connection.query(
      `INSERT INTO container_items (
        id, container_id, product_id, quantity, unit_price,
        batch_number, expiry_date, notes, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [
        itemId,
        containerId,
        product_id,
        quantity,
        unit_price || null,
        batch_number || null,
        expiry_date || null,
        notes || null
      ]
    );

    // Log in inventory movements
    await connection.query(
      `INSERT INTO inventory_movements (
        id, organization_id, product_id, container_id, quantity,
        type, reference_type, reference_id, notes, created_by, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        organizationId,
        product_id,
        containerId,
        quantity,
        'in',
        'container_item',
        itemId,
        `Added to container ${container[0].id}`,
        req.user.sub
      ]
    );

    await connection.commit();

    res.status(201).json({
      message: 'Item added to container successfully',
      itemId
    });
  } catch (error) {
    await connection.rollback();
    console.error('Add container item error:', error);
    res.status(500).json({ error: 'Failed to add item to container' });
  } finally {
    connection.release();
  }
};

/**
 * Update container item
 */
export const updateContainerItem = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const { containerId, itemId } = req.params;
    const {
      quantity,
      unit_price,
      batch_number,
      expiry_date,
      notes,
      arrival_date
    } = req.body;

    // Check if item exists and belongs to org's container
    const [item] = await connection.query(
      `SELECT ci.* FROM container_items ci
       JOIN containers c ON ci.container_id = c.id
       WHERE ci.id = ? AND ci.container_id = ? AND c.organization_id = ?`,
      [itemId, containerId, organizationId]
    );

    if (item.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: 'Container item not found' });
    }

    await connection.query(
      `UPDATE container_items SET
        quantity = ?, unit_price = ?, batch_number = ?,
        expiry_date = ?, notes = ?, arrival_date = ?, updated_at = NOW()
       WHERE id = ?`,
      [
        quantity || item[0].quantity,
        unit_price || item[0].unit_price,
        batch_number || item[0].batch_number,
        expiry_date || item[0].expiry_date,
        notes || item[0].notes,
        arrival_date || item[0].arrival_date,
        itemId
      ]
    );

    await connection.commit();

    res.json({ message: 'Container item updated successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Update container item error:', error);
    res.status(500).json({ error: 'Failed to update container item' });
  } finally {
    connection.release();
  }
};

/**
 * Remove item from container
 */
export const removeContainerItem = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const { containerId, itemId } = req.params;

    // Check if item exists and belongs to org's container
    const [item] = await connection.query(
      `SELECT ci.* FROM container_items ci
       JOIN containers c ON ci.container_id = c.id
       WHERE ci.id = ? AND ci.container_id = ? AND c.organization_id = ?`,
      [itemId, containerId, organizationId]
    );

    if (item.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: 'Container item not found' });
    }

    // Log removal in inventory movements
    await connection.query(
      `INSERT INTO inventory_movements (
        id, organization_id, product_id, container_id, quantity,
        type, reference_type, reference_id, notes, created_by, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        organizationId,
        item[0].product_id,
        containerId,
        -item[0].quantity,
        'out',
        'container_removal',
        itemId,
        `Removed from container`,
        req.user.sub
      ]
    );

    await connection.query(
      'DELETE FROM container_items WHERE id = ?',
      [itemId]
    );

    await connection.commit();

    res.json({ message: 'Item removed from container successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Remove container item error:', error);
    res.status(500).json({ error: 'Failed to remove item from container' });
  } finally {
    connection.release();
  }
};

// ==================== STOCK ADJUSTMENTS ====================

/**
 * Get stock adjustments
 */
export const getStockAdjustments = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const {
      page = 1,
      limit = 20,
      search = '',
      type,
      status,
      startDate,
      endDate
    } = req.query;

    const offset = (page - 1) * limit;

    let query = `
      SELECT 
        sa.*,
        u.name as created_by_name,
        COUNT(sai.id) as item_count
      FROM stock_adjustments sa
      LEFT JOIN users u ON sa.created_by = u.id
      LEFT JOIN stock_adjustment_items sai ON sa.id = sai.adjustment_id
      WHERE sa.organization_id = ?
    `;
    
    const queryParams = [organizationId];

    if (search) {
      query += ` AND (sa.reason LIKE ? OR sa.reference_number LIKE ?)`;
      const searchTerm = `%${search}%`;
      queryParams.push(searchTerm, searchTerm);
    }

    if (type) {
      query += ` AND sa.adjustment_type = ?`;
      queryParams.push(type);
    }

    if (status) {
      query += ` AND sa.status = ?`;
      queryParams.push(status);
    }

    if (startDate) {
      query += ` AND sa.created_at >= ?`;
      queryParams.push(startDate);
    }

    if (endDate) {
      query += ` AND sa.created_at <= ?`;
      queryParams.push(endDate);
    }

    query += ` GROUP BY sa.id ORDER BY sa.created_at DESC LIMIT ? OFFSET ?`;
    queryParams.push(parseInt(limit), parseInt(offset));

    const [rows] = await pool.query(query, queryParams);

    // Get total count
    const [countResult] = await pool.query(
      `SELECT COUNT(*) as total FROM stock_adjustments WHERE organization_id = ?`,
      [organizationId]
    );

    res.json({
      adjustments: rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: countResult[0].total,
        pages: Math.ceil(countResult[0].total / limit)
      }
    });
  } catch (error) {
    console.error('Get stock adjustments error:', error);
    res.status(500).json({ error: 'Failed to fetch stock adjustments' });
  }
};

/**
 * Create stock adjustment
 */
export const createStockAdjustment = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const organizationId = req.organizationId;
    const adjustmentId = uuidv4();
    const {
      adjustment_type,
      reason,
      reference_number,
      notes,
      items
    } = req.body;

    if (!items || items.length === 0) {
      await connection.rollback();
      return res.status(400).json({ error: 'At least one item is required' });
    }

    // Create adjustment record
    await connection.query(
      `INSERT INTO stock_adjustments (
        id, organization_id, adjustment_type, reason,
        reference_number, notes, status, created_by, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, NOW(), NOW())`,
      [
        adjustmentId,
        organizationId,
        adjustment_type,
        reason,
        reference_number || null,
        notes || null,
        req.user.sub
      ]
    );

    // Add items and update stock
    for (const item of items) {
      const itemId = uuidv4();
      
      // Get current stock
      const [product] = await connection.query(
        'SELECT current_stock FROM products WHERE id = ? AND organization_id = ?',
        [item.product_id, organizationId]
      );

      if (product.length === 0) {
        await connection.rollback();
        return res.status(404).json({ error: `Product ${item.product_id} not found` });
      }

      const newQuantity = item.new_quantity;
      const oldQuantity = product[0].current_stock;
      const quantityChange = newQuantity - oldQuantity;

      await connection.query(
        `INSERT INTO stock_adjustment_items (
          id, adjustment_id, product_id, old_quantity,
          new_quantity, quantity_change, reason, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          itemId,
          adjustmentId,
          item.product_id,
          oldQuantity,
          newQuantity,
          quantityChange,
          item.reason || null
        ]
      );

      // Update product stock
      await connection.query(
        'UPDATE products SET current_stock = ?, updated_at = NOW() WHERE id = ?',
        [newQuantity, item.product_id]
      );

      // Log inventory movement
      await connection.query(
        `INSERT INTO inventory_movements (
          id, organization_id, product_id, quantity,
          type, reference_type, reference_id, notes, created_by, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          uuidv4(),
          organizationId,
          item.product_id,
          quantityChange,
          'adjustment',
          'stock_adjustment',
          adjustmentId,
          `Stock adjustment: ${reason}`,
          req.user.sub
        ]
      );
    }

    // Update adjustment status to completed
    await connection.query(
      'UPDATE stock_adjustments SET status = ? WHERE id = ?',
      ['completed', adjustmentId]
    );

    // Log in audit trail
    await connection.query(
      `INSERT INTO audit_logs (
        id, user_id, organization_id, action, entity_type, entity_id, details, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [
        uuidv4(),
        req.user.sub,
        organizationId,
        'CREATE',
        'stock_adjustment',
        adjustmentId,
        JSON.stringify({ type: adjustment_type, items: items.length })
      ]
    );

    await connection.commit();

    res.status(201).json({
      message: 'Stock adjustment completed successfully',
      adjustmentId
    });
  } catch (error) {
    await connection.rollback();
    console.error('Create stock adjustment error:', error);
    res.status(500).json({ error: 'Failed to create stock adjustment' });
  } finally {
    connection.release();
  }
};

/**
 * Get stock adjustment by ID
 */
export const getStockAdjustmentById = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const { id } = req.params;

    const [adjustmentRows] = await pool.query(
      `SELECT sa.*, u.name as created_by_name
       FROM stock_adjustments sa
       LEFT JOIN users u ON sa.created_by = u.id
       WHERE sa.id = ? AND sa.organization_id = ?`,
      [id, organizationId]
    );

    if (adjustmentRows.length === 0) {
      return res.status(404).json({ error: 'Stock adjustment not found' });
    }

    const adjustment = adjustmentRows[0];

    // Get adjustment items with product details
    const [items] = await pool.query(
      `SELECT 
        sai.*,
        p.name as product_name,
        p.sku as product_sku
       FROM stock_adjustment_items sai
       LEFT JOIN products p ON sai.product_id = p.id
       WHERE sai.adjustment_id = ?`,
      [id]
    );

    adjustment.items = items;

    res.json(adjustment);
  } catch (error) {
    console.error('Get stock adjustment error:', error);
    res.status(500).json({ error: 'Failed to fetch stock adjustment' });
  }
};

// ==================== INVENTORY MOVEMENTS ====================

/**
 * Get inventory movements with filters
 */
export const getInventoryMovements = async (req, res) => {
  try {
    const organizationId = req.organizationId;
    const {
      page = 1,
      limit = 50,
      productId,
      containerId,
      type,
      startDate,
      endDate,
      search = ''
    } = req.query;

    const offset = (page - 1) * limit;

    let query = `
      SELECT 
        im.*,
        p.name as product_name,
        p.sku as product_sku,
        c.container_number,
        u.name as user_name
      FROM inventory_movements im
      LEFT JOIN products p ON im.product_id = p.id
      LEFT JOIN containers c ON im.container_id = c.id
      LEFT JOIN users u ON im.created_by = u.id
      WHERE im.organization_id = ?
    `;
    
    const queryParams = [organizationId];

    if (productId) {
      query += ` AND im.product_id = ?`;
      queryParams.push(productId);
    }

    if (containerId) {
      query += ` AND im.container_id = ?`;
      queryParams.push(containerId);
    }

    if (type) {
      query += ` AND im.type = ?`;
      queryParams.push(type);
    }

    if (startDate) {
      query += ` AND im.created_at >= ?`;
      queryParams.push(startDate);
    }

    if (endDate) {
      query += ` AND im.created_at <= ?`;
      queryParams.push(endDate);
    }

    if (search) {
      query += ` AND (p.name LIKE ? OR p.sku LIKE ? OR c.container_number LIKE ?)`;
      const searchTerm = `%${search}%`;
      queryParams.push(searchTerm, searchTerm, searchTerm);
    }

    query += ` ORDER BY im.created_at DESC LIMIT ? OFFSET ?`;
    queryParams.push(parseInt(limit), parseInt(offset));

    const [rows] = await pool.query(query, queryParams);

    // Get total count
    const countQuery = `SELECT COUNT(*) as total FROM inventory_movements WHERE organization_id = ?`;
    const [countResult] = await pool.query(countQuery, [organizationId]);

    res.json({
      movements: rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: countResult[0].total,
        pages: Math.ceil(countResult[0].total / limit)
      }
    });
  } catch (error) {
    console.error('Get inventory movements error:', error);
    res.status(500).json({ error: 'Failed to fetch inventory movements' });
  }
};

/**
 * Get inventory movement summary
 */
export const getMovementSummary = async (req, res) => {
  try {
    const organizationId = req.organizationId;

    // Get counts by type
    const [typeCounts] = await pool.query(
      `SELECT 
        type,
        COUNT(*) as count,
        SUM(ABS(quantity)) as total_quantity
       FROM inventory_movements
       WHERE organization_id = ?
       GROUP BY type`,
      [organizationId]
    );

    // Get daily summary for last 30 days
    const [dailySummary] = await pool.query(
      `SELECT 
        DATE(created_at) as date,
        COUNT(*) as movement_count,
        SUM(CASE WHEN type = 'in' THEN quantity ELSE 0 END) as total_in,
        SUM(CASE WHEN type = 'out' THEN ABS(quantity) ELSE 0 END) as total_out
       FROM inventory_movements
       WHERE organization_id = ?
         AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       GROUP BY DATE(created_at)
       ORDER BY date DESC`,
      [organizationId]
    );

    // Get top moved products
    const [topProducts] = await pool.query(
      `SELECT 
        p.id, p.name, p.sku,
        COUNT(im.id) as movement_count,
        SUM(im.quantity) as net_quantity
       FROM inventory_movements im
       JOIN products p ON im.product_id = p.id
       WHERE im.organization_id = ?
       GROUP BY p.id
       ORDER BY movement_count DESC
       LIMIT 10`,
      [organizationId]
    );

    res.json({
      typeCounts,
      dailySummary,
      topProducts
    });
  } catch (error) {
    console.error('Get movement summary error:', error);
    res.status(500).json({ error: 'Failed to fetch movement summary' });
  }
};