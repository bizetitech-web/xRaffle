import jwt from 'jsonwebtoken';
import { validationResult } from 'express-validator';
import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import pool from '../config/database.js';

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-key';
const JWT_EXPIRES_IN = '7d';
const BCRYPT_ROUNDS = 12; // Increased from default 10 for better security

const issueToken = (payload) =>
  jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

const buildUserResponse = (row) => ({
  id: row.id,
  email: row.email,
  name: row.name,
  firstName: row.name?.split(' ')[0] || '',
  lastName: row.name?.split(' ').slice(1).join(' ') || '',
  role: {
    id: row.role_id,
    name: row.role_name || 'user',
    level: row.role_level || null
  },
  organization: { 
    id: row.organization_id, 
    name: row.organization_name,
    code: row.organization_code || null
  },
  permissions: row.permissions || [],
  lastLogin: row.last_login || null,
  createdAt: row.created_at,
});

export const register = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const {
    email,
    password,
    firstName,
    lastName,
    organizationName,
    phone,
    address,
    city,
    state,
    country,
    postalCode,
  } = req.body;

  // Validate required fields
  if (!email || !password || !firstName || !lastName || !organizationName) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const fullName = `${firstName} ${lastName}`.trim();
  // Generate a more unique org code with timestamp
  const timestamp = Date.now().toString(36);
  const orgCode = `${organizationName?.toLowerCase().replace(/\s+/g, '-') || 'org'}-${timestamp}-${Math.random()
    .toString(36)
    .slice(-4)}`;

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    // Check if email already exists
    const [existing] = await connection.query(
      'SELECT id FROM users WHERE email = ? LIMIT 1', 
      [email]
    );
    if (existing.length > 0) {
      await connection.rollback();
      return res.status(400).json({ error: 'Email already registered' });
    }

    // Check if organization name already exists (optional, but good practice)
    const [orgExists] = await connection.query(
      'SELECT id FROM organizations WHERE name = ? LIMIT 1',
      [organizationName]
    );
    if (orgExists.length > 0) {
      await connection.rollback();
      return res.status(400).json({ error: 'Organization name already exists' });
    }

    // Create organization
    const organizationId = crypto.randomUUID();
    await connection.query(
      `INSERT INTO organizations (
        id, name, email, phone, address, city, state, country, 
        postal_code, code, is_active, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'active', NOW(), NOW())`,
      [
        organizationId,
        organizationName,
        email,
        phone || null,
        address || null,
        city || null,
        state || null,
        country || null,
        postalCode || null,
        orgCode,
      ]
    );

    // Create user
    const userId = crypto.randomUUID();
    const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);

    await connection.query(
      `INSERT INTO users (
        id, organization_id, name, email, password_hash, 
        phone, is_active, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, 1, NOW())`,
      [
        userId, 
        organizationId, 
        fullName, 
        email, 
        passwordHash, 
        phone || null
      ]
    );

    // Get org_admin role - handle case where role doesn't exist
    const [roleRows] = await connection.query(
      'SELECT id, name, level FROM roles WHERE name = ? OR level = ? LIMIT 1', 
      ['org_admin', 2]
    );
    
    let roleId = roleRows[0]?.id;
    let roleName = roleRows[0]?.name || 'org_admin';
    
    if (!roleId) {
      // Fallback: create org_admin role if it doesn't exist
      roleId = crypto.randomUUID();
      await connection.query(
        `INSERT INTO roles (id, name, description, level, created_at, updated_at)
         VALUES (?, ?, ?, ?, NOW(), NOW())`,
        [roleId, 'org_admin', 'Organization administrator', 2]
      );
    }

    // Assign role to user
    await connection.query(
      'INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)', 
      [userId, roleId]
    );

    await connection.commit();

    // Get organization details for response
    const [orgRows] = await pool.query(
      'SELECT name, code FROM organizations WHERE id = ?',
      [organizationId]
    );
    const organization = orgRows[0];

    // Generate token with comprehensive payload
    const token = issueToken({
      sub: userId,
      email,
      name: fullName,
      role: roleName,
      roleId: roleId,
      organizationId: organizationId,
      organization: { 
        id: organizationId, 
        name: organizationName,
        code: organization.code 
      },
    });

    return res.status(201).json({
      message: 'Registration successful',
      token,
      user: {
        id: userId,
        email,
        name: fullName,
        firstName,
        lastName,
        role: {
          id: roleId,
          name: roleName
        },
        organization: { 
          id: organizationId, 
          name: organizationName,
          code: organization.code
        },
      },
    });
  } catch (error) {
    await connection.rollback();
    console.error('Registration error:', error);
    return res.status(500).json({ 
      error: 'Registration failed',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  } finally {
    connection.release();
  }
};

export const login = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  try {
    const [rows] = await pool.query(
      `SELECT 
        u.id,
        u.organization_id,
        u.name,
        u.email,
        u.password_hash,
        u.phone,
        u.is_active,
        u.created_at,
        o.name AS organization_name,
        o.code AS organization_code,
        ur.role_id,
        r.name AS role_name,
        r.level AS role_level
       FROM users u
       LEFT JOIN organizations o ON o.id = u.organization_id
       LEFT JOIN user_roles ur ON ur.user_id = u.id
       LEFT JOIN roles r ON r.id = ur.role_id
       WHERE u.email = ?
       LIMIT 1`,
      [email]
    );

    if (rows.length === 0) {
      // Use generic error message to prevent user enumeration
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const user = rows[0];
    
    // Check if user is active
    if (!user.is_active) {
      return res.status(403).json({ error: 'Account is inactive. Please contact support.' });
    }

    // Verify password
    const passwordMatch = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Update last login timestamp (skip if column doesn't exist)
    try {
      await pool.query('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);
    } catch (err) {
      // Column last_login may not exist in current schema; ignore
    }

    // Get user permissions (optional - can be fetched on demand)
    const [permissions] = await pool.query(
      `SELECT p.name, p.module
       FROM permissions p
       JOIN role_permissions rp ON p.id = rp.permission_id
       WHERE rp.role_id = ?`,
      [user.role_id]
    );

    // Generate token with comprehensive payload
    const token = issueToken({
      sub: user.id,
      email: user.email,
      name: user.name,
      role: user.role_name || 'user',
      roleId: user.role_id,
      roleLevel: user.role_level,
      organizationId: user.organization_id,
      organization: { 
        id: user.organization_id, 
        name: user.organization_name,
        code: user.organization_code 
      },
    });

    return res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        firstName: user.name?.split(' ')[0] || '',
        lastName: user.name?.split(' ').slice(1).join(' ') || '',
        role: {
          id: user.role_id,
          name: user.role_name || 'user',
          level: user.role_level
        },
        organization: { 
          id: user.organization_id, 
          name: user.organization_name,
          code: user.organization_code
        },
        permissions: permissions.map(p => p.name), // Optional: include basic permissions
        lastLogin: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ 
      error: 'Login failed',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

export const getProfile = async (req, res) => {
  try {
    const userId = req.user?.sub;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const [rows] = await pool.query(
      `SELECT 
        u.id,
        u.organization_id,
        u.name,
        u.email,
        u.password_hash,
        u.phone,
        u.is_active,
        u.created_at,
        o.name AS organization_name,
        o.code AS organization_code,
        ur.role_id,
        r.name AS role_name,
        r.level AS role_level
       FROM users u
       LEFT JOIN organizations o ON o.id = u.organization_id
       LEFT JOIN user_roles ur ON ur.user_id = u.id
       LEFT JOIN roles r ON r.id = ur.role_id
       WHERE u.id = ?
       LIMIT 1`,
      [userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = rows[0];

    // Get user permissions
    const [permissions] = await pool.query(
      `SELECT p.name, p.module
       FROM permissions p
       JOIN role_permissions rp ON p.id = rp.permission_id
       WHERE rp.role_id = ?`,
      [user.role_id]
    );

    return res.json({ 
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        firstName: user.first_name,
        lastName: user.last_name,
        phone: user.phone,
        role: {
          id: user.role_id,
          name: user.role_name || 'user',
          level: user.role_level
        },
        organization: { 
          id: user.organization_id, 
          name: user.organization_name,
          code: user.organization_code
        },
        permissions: permissions.map(p => p.name),
        isActive: user.is_active,
        lastLogin: user.last_login,
        createdAt: user.created_at,
      } 
    });
  } catch (error) {
    console.error('Profile error:', error);
    return res.status(500).json({ 
      error: 'Failed to fetch profile',
      details: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};

// Optional: Refresh token endpoint
export const refreshToken = async (req, res) => {
  try {
    const userId = req.user?.sub;
    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const [rows] = await pool.query(
            `SELECT u.id, u.organization_id, u.name, u.email, u.password_hash, u.phone, u.is_active, u.created_at,
              o.name AS organization_name, o.code AS organization_code,
              ur.role_id, r.name AS role_name
       FROM users u
       LEFT JOIN organizations o ON o.id = u.organization_id
       LEFT JOIN user_roles ur ON ur.user_id = u.id
       LEFT JOIN roles r ON r.id = ur.role_id
       WHERE u.id = ?`,
      [userId]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = rows[0];

    const token = issueToken({
      sub: user.id,
      email: user.email,
      name: user.name,
      role: user.role_name || 'user',
      roleId: user.role_id,
      organizationId: user.organization_id,
      organization: { 
        id: user.organization_id, 
        name: user.organization_name,
        code: user.organization_code 
      },
    });

    return res.json({ token });
  } catch (error) {
    console.error('Token refresh error:', error);
    return res.status(500).json({ error: 'Failed to refresh token' });
  }
};

// Optional: Logout (client-side only, but can blacklist tokens if needed)
export const logout = async (req, res) => {
  // In a stateless JWT setup, logout is handled client-side by removing the token
  // For enhanced security, you could implement a token blacklist here
  return res.json({ message: 'Logged out successfully' });
};