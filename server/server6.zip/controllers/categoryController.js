export const listCategories = (req, res) => res.json([]);
export const createCategory = (req, res) => res.status(201).json(req.body);
